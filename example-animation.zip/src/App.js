import {motion} from "framer-motion";
import {useState} from "react";
import './App.css';

function App() {
    const [rotate, setRotate] = useState(0);
    const [XVal, setXVal] = useState(0);
    const [centerVal, setCenterVal] = useState(5);
    const [newRadarY, setNewRadarY] = useState(0);
    const [pitch, setPitch] = useState(0);
    const [roll, setRoll] = useState(0);

    const [topLeftVal, setTopLeftVal] = useState([0, -10, -15, -30, -40, -45, -60]);


    function template({rotate, x, y}) {
        return `rotate(${rotate}) translateX(${x}) translateY(${y})`
    }

    return (
        <div>
            <div className="container"></div>

            <button onClick={() => {
                if (centerVal === 0) return false;
                setXVal(XVal + 8);
                setCenterVal(parseFloat((centerVal - 0.1).toFixed(1)));
            }}>+
            </button>
            <button onClick={() => {
                setXVal(XVal - 8);
                setCenterVal(parseFloat((centerVal + 0.1).toFixed(1)));
            }}>-
            </button>
            <motion.p>{centerVal}</motion.p>


            <button
                onClick={() => {
                    setNewRadarY(newRadarY + 5);
                }}
            >
                + New Radar Y
            </button>
            <div className="newRadar-container">
                <motion.div
                    className="newRadar-data"
                    transformTemplate={template}
                    animate={{rotate: 30}}
                    style={{rotate: 0, x: 0, y: newRadarY}}
                >
                    {
                        [1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map(i => (
                            <div className="newRadar-data-row">
                                <div className="newRadar-data-row-item">
                                    <span>{i * 5}</span>
                                </div>
                                <div className="newRadar-data-row-item">
                                    <span>{i * 5}</span>
                                </div>
                            </div>
                        ))
                    }
                </motion.div>
                <div className="plus">
                    <div className="plus-vertical">

                    </div>
                    <div className="plus-horizontal">

                    </div>
                </div>
                <div className="barContainer">
                    <div className="bar bar-1">
                    </div>
                    <div className="bar bar-2">
                    </div>
                </div>
            </div>

            <div className="radarContainer">
                <motion.div
                    className="radar"
                    animate={{
                        rotate: [10, 20, 30, 40, 50, 60, 70, 80, 90, 120, 150, 0],
                    }}
                    transition={{type: 'spring', duration: 7}}
                >
                    <div className="topContainer">
                        <div className="topContainer-item-1">
                            <motion.div
                                style={{display: 'inline', position: 'absolute'}}
                                animate={{y: topLeftVal, opacity: [1, 0.5, 0.3, 0]}}
                            >
                                5
                            </motion.div>
                            <motion.div
                                style={{display: 'inline', position: 'absolute'}}
                                animate={{y: [10, 7, 4, 1, 0], opacity: [0.2, 0.4, 0.6, 0.8, 1]}}
                            >
                                6
                            </motion.div>
                        </div>
                        <div className="topContainer-item-2">
                            5
                        </div>
                    </div>
                    <div className="barContainer">
                        <div className="bar bar-1">
                        </div>
                        <div className="bar bar-2">
                        </div>
                    </div>
                    <div className="bottomContainer">
                        <div className="itemContainer">
                            <div className="bottomContainer-item-1">
                                5
                            </div>
                            <div className="bottomContainer-item-2">
                                5
                            </div>
                        </div>
                        <div className="itemContainer">
                            <div className="bottomContainer-item-1">
                                5
                            </div>
                            <div className="bottomContainer-item-2">
                                5
                            </div>
                        </div>
                    </div>
                </motion.div>
                <div className="plus">
                    <div className="plus-vertical">

                    </div>
                    <div className="plus-horizontal">

                    </div>
                </div>
                <div className="radar-dots radar-dot1">.</div>
                <div className="radar-dots radar-dot2">.</div>
                <div className="radar-dots radar-dot3">.</div>
                <div className="radar-dots radar-dot4">.</div>
                <div className="radar-dots radar-dot5">.</div>
                <div className="radar-dots radar-dot6">.</div>
                <div className="radar-dots radar-dot7">.</div>
                <div className="radar-dots radar-dot8">.</div>
                <div className="radar-dots radar-dot9">.</div>
                <div className="radar-dots radar-dot10">.</div>
                <div className="radar-dots radar-dot11">.</div>
                <div className="radar-dots radar-dot12">.</div>
                <div className="radar-dots radar-dot13">.</div>
                <motion.div
                    className="radar-dots radar-dot-hand"
                    animate={{
                        rotate: [240, 230, 220, 210, 200],
                    }}
                >
                    .
                </motion.div>
            </div>


            <button onClick={() => setRotate(rotate + 7.2)}>+</button>
            <button onClick={() => setRotate(rotate - 7.2)}>-</button>

            <div className="clock">
                <motion.div
                    className="handContainer"
                    animate={{
                        rotate: rotate,
                    }}
                >
                    <motion.div
                        className="hand"
                        style={{originY: 0, originZ: 0}}
                        animate={{
                            rotate: [0, 0],
                        }}
                        transition={{delay: 10}}
                    >
                    </motion.div>
                </motion.div>

                <div className="infoContainer">
                    <div className="speedInfo">SPEED</div>
                    <div className="speedValue">0347</div>
                    <div className="typeInfo">KNOT</div>
                </div>
                <div className="dots dot0">.</div>
                <div className="dots dot1">.</div>
                <div className="dots dot2">.</div>
                <div className="dots dot3">.</div>
                <div className="dots dot4">.</div>
                <div className="dots dot5">.</div>
                <div className="dots dot6">.</div>
                <div className="dots dot7">.</div>
                <div className="dots dot8">.</div>
                <div className="dots dot9">.</div>
                <div className="dots dot10">.</div>
                <div className="dots dot11">.</div>
                <div className="dots dot12">.</div>
                <div className="dots dot13">.</div>
                <div className="dots dot14">.</div>
                <div className="dots dot15">.</div>
                <div className="dots dot16">.</div>
                <div className="dots dot17">.</div>
                <div className="dots dot18">.</div>
                <div className="dots dot19">.</div>
                <div className="dots dot20">.</div>
                <div className="dots dot21">.</div>
                <div className="dots dot22">.</div>
                <div className="dots dot23">.</div>
                <div className="dots dot24">.</div>
                <div className="dots dot25">.</div>
                <div className="dots dot26">.</div>
                <div className="dots dot27">.</div>
                <div className="dots dot28">.</div>
                <div className="dots dot29">.</div>
                <div className="dots dot30">.</div>
                <div className="dots dot31">.</div>
                <div className="dots dot32">.</div>
                <div className="dots dot33">.</div>
                <div className="dots dot34">.</div>
                <div className="dots dot35">.</div>
                <div className="dots dot36">.</div>
                <div className="dots dot37">.</div>
                <div className="dots dot38">.</div>
                <div className="dots dot39">.</div>
                <div className="dots dot40">.</div>
                <div className="dots dot41">.</div>
                <div className="dots dot42">.</div>
                <div className="dots dot43">.</div>
                <div className="dots dot44">.</div>
                <div className="dots dot45">.</div>
                <div className="dots dot46">.</div>
                <div className="dots dot47">.</div>
                <div className="dots dot48">.</div>
                <div className="dots dot49">.</div>
                <div className="dots dot51">.</div>


                <div className="numbers no0">
                    <p className="flipNumber">0</p>
                </div>
                <div className="numbers no1">
                    <p className="flipNumber">1</p>
                </div>
                <div className="numbers no2">
                    <p className="flipNumber">2</p>
                </div>
                <div className="numbers no3">
                    <p className="flipNumberLower">3</p>
                </div>
                <div className="numbers no4">
                    <p className="flipNumberLower">4</p>
                </div>
                <div className="numbers no5">
                    <p className="flipNumberLower">5</p>
                </div>
                <div className="numbers no6">
                    <p className="flipNumberLower">6</p>
                </div>
                <div className="numbers no7">
                    <p className="flipNumberLower">7</p>
                </div>
                <div className="numbers no8">
                    <p className="flipNumber">8</p>
                </div>
                <div className="numbers no9">
                    <p className="flipNumber">9</p>
                </div>

            </div>

            <div className="parent">
                <div className="area cover">
                    <motion.div
                        className='ruler'
                        initial={{
                            opacity: 0
                        }}
                        animate={{
                            opacity: 1,
                            x: XVal
                        }}
                        transition={{type: "spring", stiffness: 100}}
                    >
                        <div className='cm'>
                            <div className='mm'></div>
                            <div className='mm'></div>
                            <div className='mm'></div>
                            <div className='mm'></div>
                            <div className='mm'></div>
                            <div className='mm'></div>
                            <div className='mm'></div>
                            <div className='mm'></div>
                            <div className='mm'></div>
                        </div>
                        <div className='cm'>
                            <div className='mm'></div>
                            <div className='mm'></div>
                            <div className='mm'></div>
                            <div className='mm'></div>
                            <div className='mm'></div>
                            <div className='mm'></div>
                            <div className='mm'></div>
                            <div className='mm'></div>
                            <div className='mm'></div>
                        </div>
                        <div className='cm'>
                            <div className='mm'></div>
                            <div className='mm'></div>
                            <div className='mm'></div>
                            <div className='mm'></div>
                            <div className='mm'></div>
                            <div className='mm'></div>
                            <div className='mm'></div>
                            <div className='mm'></div>
                            <div className='mm'></div>
                        </div>
                        <div className='cm'>
                            <div className='mm'></div>
                            <div className='mm'></div>
                            <div className='mm'></div>
                            <div className='mm'></div>
                            <div className='mm'></div>
                            <div className='mm'></div>
                            <div className='mm'></div>
                            <div className='mm'></div>
                            <div className='mm'></div>
                        </div>
                        <div className='cm'>
                            <div className='mm'></div>
                            <div className='mm'></div>
                            <div className='mm'></div>
                            <div className='mm'></div>
                            <div className='mm'></div>
                            <div className='mm'></div>
                            <div className='mm'></div>
                            <div className='mm'></div>
                            <div className='mm'></div>
                        </div>
                        <div className='cm'>
                            <div className='mm'></div>
                            <div className='mm'></div>
                            <div className='mm'></div>
                            <div className='mm'></div>
                            <div className='mm'></div>
                            <div className='mm'></div>
                            <div className='mm'></div>
                            <div className='mm'></div>
                            <div className='mm'></div>
                        </div>
                        <div className='cm'>
                            <div className='mm'></div>
                            <div className='mm'></div>
                            <div className='mm'></div>
                            <div className='mm'></div>
                            <div className='mm'></div>
                            <div className='mm'></div>
                            <div className='mm'></div>
                            <div className='mm'></div>
                            <div className='mm'></div>
                        </div>
                        <div className='cm'>
                            <div className='mm'></div>
                            <div className='mm'></div>
                            <div className='mm'></div>
                            <div className='mm'></div>
                            <div className='mm'></div>
                            <div className='mm'></div>
                            <div className='mm'></div>
                            <div className='mm'></div>
                            <div className='mm'></div>
                        </div>
                        <div className='cm'>
                            <div className='mm'></div>
                            <div className='mm'></div>
                            <div className='mm'></div>
                            <div className='mm'></div>
                            <div className='mm'></div>
                            <div className='mm'></div>
                            <div className='mm'></div>
                            <div className='mm'></div>
                            <div className='mm'></div>
                        </div>
                        <div className='cm'>
                            <div className='mm'></div>
                            <div className='mm'></div>
                            <div className='mm'></div>
                            <div className='mm'></div>
                            <div className='mm'></div>
                            <div className='mm'></div>
                            <div className='mm'></div>
                            <div className='mm'></div>
                            <div className='mm'></div>
                        </div>
                        <div className='cm'></div>
                    </motion.div>
                    <motion.p
                        key={centerVal}
                        style={{border: 'solid #2dba36', borderRadius: 5, padding: '0px 6px 0px 6px', color: '#2dba36'}}
                        initial={{
                            opacity: 0.5
                        }}
                        animate={{
                            opacity: 1,
                        }}
                        transition={{type: "spring", stiffness: 100}}
                    >
                        {centerVal * 10}
                    </motion.p>
                </div>
            </div>

            {/*<div style={{ border: 'solid' }}>
                <div style={{width: 400, border: 'solid red', height: 100, margin: 'auto', position: 'absolute'}}>

                </div>
                <div style={{width: 200, border: 'solid', height: 50, margin: 'auto', position: 'absolute'}}>

                </div>
            </div>*/}

            {/*<div style={{
                display: 'flex',
                flexDirection: 'column',
                justifyContent: 'center',
                alignItems: 'center',
                border: 'solid',
                width: 500,
                height: 300,
                borderRadius: 10,
                marginLeft: 400,
                overflow: 'hidden',
            }}>

            </div>*/}
            {/*<motion.div
                key={XVal}
                initial={{
                    opacity: 0
                }}
                animate={{
                    opacity: 1
                }}
            >
                {XVal}
            </motion.div>*/}
            <button onClick={() => setXVal(XVal + 8)}>+</button>
            <button onClick={() => setXVal(XVal - 8)}>-</button>

            <div className="clock">
                <motion.div
                    className="seconds"
                    animate={{
                        rotate: [6, 12, 18, 120, 150, 180, 210, 240, 270, 300, 330, 360],
                    }}
                    transition={{
                        duration: 5,
                        ease: "easeInOut",
                        repeat: Infinity,
                    }}
                >
                </motion.div>
            </div>


            {/*<article className="clock">
                <div className="hours-container">
                    <div className="hours"></div>
                </div>
                <div className="minutes-container">
                    <div className="minutes"></div>
                </div>
                <div className="seconds-container">
                    <div className="seconds"></div>
                </div>
            </article>

            <motion.div
                animate={{
                    rotate: rotate
                }}
            >
                <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="600"
                    height="600"
                    viewBox="0 0 600 600"
                >
                    <rect width="100%" height="100%" fill="transparent"></rect>
                    <rect
                        width="600"
                        height="600"
                        x="-300"
                        y="-300"
                        fill="#FFF"
                        fillOpacity="0"
                        rx="0"
                        ry="0"
                        transform="translate(300 300)"
                        vectorEffect="non-scaling-stroke"
                    ></rect>
                    <path
                        fill="#0BEF1D"
                        stroke="#000"
                        strokeWidth="0"
                        d="M0 42.875c-23.642 0-42.875-19.233-42.875-42.875S-23.642-42.875 0-42.875 42.875-23.642 42.875 0 23.642 42.875 0 42.875zm0-83.75c-22.539 0-40.875 18.336-40.875 40.875 0 22.538 18.336 40.875 40.875 40.875 22.538 0 40.875-18.337 40.875-40.875 0-22.539-18.337-40.875-40.875-40.875z"
                        transform="matrix(2.8 0 0 2.8 300 300)"
                        vectorEffect="non-scaling-stroke"
                    ></path>
                    <rect
                        width="66.17"
                        height="66.17"
                        x="-33.085"
                        y="-33.085"
                        fill="#0BEF1D"
                        stroke="#000"
                        strokeWidth="0"
                        rx="0"
                        ry="0"
                        transform="matrix(1.25 0 0 .08 118.36 143.56)"
                        vectorEffect="non-scaling-stroke"
                    ></rect>
                    <rect
                        width="66.17"
                        height="66.17"
                        x="-33.085"
                        y="-33.085"
                        fill="#0BEF1D"
                        stroke="#000"
                        strokeWidth="0"
                        rx="0"
                        ry="0"
                        transform="matrix(1.25 0 0 .08 113.36 457.56)"
                        vectorEffect="non-scaling-stroke"
                    ></rect>
                    <rect
                        width="66.17"
                        height="66.17"
                        x="-33.085"
                        y="-33.085"
                        fill="#0BEF1D"
                        stroke="#000"
                        strokeWidth="0"
                        rx="0"
                        ry="0"
                        transform="matrix(1.25 0 0 .08 464.36 463.56)"
                        vectorEffect="non-scaling-stroke"
                    ></rect>
                    <rect
                        width="66.17"
                        height="66.17"
                        x="-33.085"
                        y="-33.085"
                        fill="#0BEF1D"
                        stroke="#000"
                        strokeWidth="0"
                        rx="0"
                        ry="0"
                        transform="matrix(1.25 0 0 .08 463.36 142.56)"
                        vectorEffect="non-scaling-stroke"
                    ></rect>
                    <rect
                        width="66.17"
                        height="66.17"
                        x="-33.085"
                        y="-33.085"
                        fill="#0BEF1D"
                        stroke="#000"
                        strokeWidth="0"
                        rx="0"
                        ry="0"
                        transform="matrix(2.27 0 0 .08 107.1 300)"
                        vectorEffect="non-scaling-stroke"
                    ></rect>
                    <rect
                        width="66.17"
                        height="66.17"
                        x="-33.085"
                        y="-33.085"
                        fill="#0BEF1D"
                        stroke="#000"
                        strokeWidth="0"
                        rx="0"
                        ry="0"
                        transform="matrix(2.27 0 0 .08 493.1 300)"
                        vectorEffect="non-scaling-stroke"
                    ></rect>
                    <rect
                        width="66.17"
                        height="66.17"
                        x="-33.085"
                        y="-33.085"
                        fill="#0BEF1D"
                        stroke="#000"
                        strokeWidth="0"
                        rx="0"
                        ry="0"
                        transform="matrix(0 -.41 .08 0 504 478.35)"
                        vectorEffect="non-scaling-stroke"
                    ></rect>
                    <rect
                        width="66.17"
                        height="66.17"
                        x="-33.085"
                        y="-33.085"
                        fill="#0BEF1D"
                        stroke="#000"
                        strokeWidth="0"
                        rx="0"
                        ry="0"
                        transform="matrix(0 -.41 .08 0 502 156.35)"
                        vectorEffect="non-scaling-stroke"
                    ></rect>
                    <rect
                        width="66.17"
                        height="66.17"
                        x="-33.085"
                        y="-33.085"
                        fill="#0BEF1D"
                        stroke="#000"
                        strokeWidth="0"
                        rx="0"
                        ry="0"
                        transform="matrix(0 -.41 .08 0 75 472.35)"
                        vectorEffect="non-scaling-stroke"
                    ></rect>
                    <rect
                        width="66.17"
                        height="66.17"
                        x="-33.085"
                        y="-33.085"
                        fill="#0BEF1D"
                        stroke="#000"
                        strokeWidth="0"
                        rx="0"
                        ry="0"
                        transform="matrix(0 -.41 .08 0 80 157.35)"
                        vectorEffect="non-scaling-stroke"
                    ></rect>
                    <path
                        fill="#0BEF1D"
                        stroke="#000"
                        strokeWidth="0"
                        d="M-9.253-36.045H9.254c1.099 0 1.988.89 1.988 1.986v22.846h22.844c1.098 0 1.984.888 1.984 1.986V9.226a1.983 1.983 0 01-1.984 1.986H11.242v22.846c0 1.099-.89 1.986-1.988 1.986H-9.253a1.986 1.986 0 01-1.985-1.986V11.213h-22.847a1.986 1.986 0 01-1.985-1.986V-9.227c0-1.099.89-1.986 1.985-1.986h22.847v-22.846c0-1.096.889-1.986 1.985-1.986z"
                        transform="matrix(.28 0 0 .28 300 300)"
                        vectorEffect="non-scaling-stroke"
                    ></path>
                </svg>
            </motion.div>

            <motion.div
                style={{border: 'solid', width: '600px', display: 'flex', flexDirection: 'column', justifyContent: 'center'}}
                animate={{
                    rotate: rotate
                }}
            >
                <div style={{display: 'flex', justifyContent: 'space-between', width: '70%', margin:'auto'}}>
                    <div style={{width: 140, height: 40, borderLeft: 'solid #0bef1d', borderTop: 'solid #0bef1d'}}></div>
                    <div style={{width: 140, height: 40, borderRight: 'solid #0bef1d', borderTop: 'solid #0bef1d'}}></div>
                </div>
                <br/>

                <div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'center'}}>
                    <div style={{width: '40%', height: 0, borderTop: 'solid #0bef1d'}}></div>
                    <div style={{width: '30%', height: 133, border: 'solid #0bef1d', borderRadius: '50%'}}></div>
                    <div style={{width: '40%', height: 0, borderTop: 'solid #0bef1d'}}></div>
                </div>

                <br/>
                <div style={{display: 'flex', justifyContent: 'space-between', width: '70%', margin:'auto'}}>
                    <div style={{width: 140, height: 40, borderLeft: 'solid #0bef1d', borderTop: 'solid #0bef1d'}}></div>
                    <div style={{width: 140, height: 40, borderRight: 'solid #0bef1d', borderTop: 'solid #0bef1d'}}></div>
                </div>
            </motion.div>

            <p>{rotate}</p>
            <button onClick={() => setRotate(rotate + 5)}>+</button>
            <button onClick={() => setRotate(rotate - 5)}>-</button>
            <motion.div
                initial={{opacity: 0}}
                animate={{opacity: 1}}
                transition={{delay: 0.5, duration: 1}}
            >
                <h2>Welcome</h2>
            </motion.div>

            <motion.div style={{display: 'flex', flexDirection: 'row', alignItems: 'center'}}>
                <motion.div
                    style={{
                        cursor: 'pointer',
                        display: 'flex',
                        border: '0.1px solid',
                        borderRadius: 5,
                        padding: 4,
                        color: '#ffffff',
                        marginLeft: 5
                    }}
                    initial={{x: '-100vw'}}
                    animate={{x: 0}}
                    whileHover={{
                        y: -5,
                        transition: {ease: "easeOut", duration: 0.2, delay: 0.2},
                    }}
                >
                    Image1
                </motion.div>
                <motion.div
                    style={{
                        cursor: 'pointer',
                        display: 'flex',
                        border: '0.1px solid',
                        borderRadius: 5,
                        padding: 4,
                        color: '#ffffff',
                        marginLeft: 5
                    }}
                    initial={{x: '-100vw'}}
                    animate={{x: 0}}
                    whileHover={{
                        y: -5,
                        transition: {ease: "easeOut", duration: 0.2, delay: 0.2},
                    }}
                >
                    Image1
                </motion.div>
                <motion.div style={{marginLeft: '10px'}}>
                    <motion.button
                        style={{
                            background: 'none',
                            border: '0.1px solid #ffffff',
                            backgroundColor: '#ffffff',
                            borderRadius: 7,
                            cursor: ' pointer',
                            padding: 5
                        }}
                        whileHover={{x: 5}}
                    >
                        Add
                    </motion.button>
                    <motion.div>
                        Hello Motion
                    </motion.div>
                </motion.div>
            </motion.div>*/}


            <div style={{
                display: 'flex',
                justifyContent: 'center',
                alignItems: 'center',
                width: '100%',
                marginBottom: '200px',
                flexDirection: 'column'
            }}>
                <button onClick={() => {
                    setPitch(pitch + 1);
                }}>
                    + Pitch
                </button>

                <button onClick={() => {
                    setRoll(roll + 1);
                }}>
                    + Roll
                </button>

                <div>Pitch : {pitch}</div>
                <div>Roll : {roll}</div>
                <svg height="500px" id="SVGRoot" width="500px" version="1.1" viewBox="0 0 500 500"
                     xmlns="http://www.w3.org/2000/svg">
                    <defs id="defs2863">
                        <clipPath id="clipPath987">
                            <g id="use989">
                                <rect height="423.06931" id="rect2563" style={{
                                    "fill": "#000000",
                                    "fillOpacity": "1",
                                    "stroke": "none",
                                    "strokeWidth": "1.9306916",
                                    "strokeMiterlimit": "4",
                                    "strokeDasharray": "none",
                                    "strokeOpacity": "1"
                                }} width="423.06931" x="37.278" y="38.452583"/>
                                <circle id="circle2565" style={{
                                    "fill": "#ffffff",
                                    "fillOpacity": "1",
                                    "stroke": "none",
                                    "strokeWidth": "2.16947818",
                                    "strokeLinecap": "round",
                                    "strokeLinejoin": "round",
                                    "strokeMiterlimit": "7.5",
                                    "strokeDasharray": "none",
                                    "strokeDashoffset": "0",
                                    "strokeOpacity": "1"
                                }} cx="249.942" cy="249.989" r="197.5"/>
                            </g>
                        </clipPath>
                        <clipPath id="clipPath1029">
                            <g id="use1031">
                                <g id="g2552" clipPath="url(#clipPath987)">
                                    <g id="g2550">
                                        <rect height="423.06931" id="rect2546" style={{
                                            "fill": "#000000",
                                            "fillOpacity": "1",
                                            "stroke": "none",
                                            "strokeWidth": "1.9306916",
                                            "strokeMiterlimit": "4",
                                            "strokeDasharray": "none",
                                            "strokeOpacity": "1"
                                        }} width="423.06931" x="37.278" y="38.452583"/>
                                        <circle id="circle2548" style={{
                                            "fill": "#ffffff",
                                            "fillOpacity": "1",
                                            "stroke": "none",
                                            "strokeWidth": "2.16947818",
                                            "strokeLinecap": "round",
                                            "strokeLinejoin": "round",
                                            "strokeMiterlimit": "7.5",
                                            "strokeDasharray": "none",
                                            "strokeDashoffset": "0",
                                            "strokeOpacity": "1"
                                        }} cx="249.942" cy="249.989" r="197.5"/>
                                    </g>
                                </g>
                            </g>
                        </clipPath>
                        <clipPath id="clipPath1029-1">
                            <g id="use1031-3">
                                <g id="g2531" clipPath="url(#clipPath987-2)">
                                    <g id="g2529">
                                        <rect height="423.06931" id="rect2525" style={{
                                            "fill": "#000000",
                                            "fillOpacity": "1",
                                            "stroke": "none",
                                            "strokeWidth": "1.9306916",
                                            "strokeMiterlimit": "4",
                                            "strokeDasharray": "none",
                                            "strokeOpacity": "1"
                                        }} width="423.06931" x="37.278" y="38.452583"/>
                                        <circle id="circle2527" style={{
                                            "fill": "#ffffff",
                                            "fillOpacity": "1",
                                            "stroke": "none",
                                            "strokeWidth": "2.16947818",
                                            "strokeLinecap": "round",
                                            "strokeLinejoin": "round",
                                            "strokeMiterlimit": "7.5",
                                            "strokeDasharray": "none",
                                            "strokeDashoffset": "0",
                                            "strokeOpacity": "1"
                                        }} cx="249.942" cy="249.989" r="197.5"/>
                                    </g>
                                </g>
                            </g>
                        </clipPath>
                        <clipPath id="clipPath987-2">
                            <g id="use989-1">
                                <rect height="423.06931" id="rect2535" style={{
                                    "fill": "#000000",
                                    "fillOpacity": "1",
                                    "stroke": "none",
                                    "strokeWidth": "1.9306916",
                                    "strokeMiterlimit": "4",
                                    "strokeDasharray": "none",
                                    "strokeOpacity": "1"
                                }} width="423.06931" x="37.278" y="38.452583"/>
                                <circle id="circle2537" style={{
                                    "fill": "#ffffff",
                                    "fillOpacity": "1",
                                    "stroke": "none",
                                    "strokeWidth": "2.16947818",
                                    "strokeLinecap": "round",
                                    "strokeLinejoin": "round",
                                    "strokeMiterlimit": "7.5",
                                    "strokeDasharray": "none",
                                    "strokeDashoffset": "0",
                                    "strokeOpacity": "1"
                                }} cx="249.942" cy="249.989" r="197.5"/>
                            </g>
                        </clipPath>
                    </defs>
                    <g id="layer1">
                        <motion.g
                            id="horizon-element"
                            animate={{
                                translateX: 0,
                                translateY: (128 / 40) * pitch,
                                rotate: roll
                            }}
                        >
                            <g id="g2699" transform="translate(-0.53033008,0.08838835)">
                                <path id="path2668" style={{
                                    "fill": "#0096c9",
                                    "fillOpacity": "1",
                                    "stroke": "none",
                                    "strokeWidth": "1.91728497",
                                    "strokeLinecap": "round",
                                    "strokeLinejoin": "round",
                                    "strokeMiterlimit": "7.5",
                                    "strokeDasharray": "none",
                                    "strokeDashoffset": "0",
                                    "strokeOpacity": "1"
                                }}
                                      d="M 649.99901,249.55179 A 399.99148,399.54176 0 0 1 250.00753,649.09355 399.99148,399.54176 0 0 1 -149.98398,249.55179 399.99148,399.54176 0 0 1 250.00753,-149.98998 399.99148,399.54176 0 0 1 649.99901,249.55179 Z"/>
                                <path id="path2670" style={{
                                    "fill": "#976300",
                                    "fillOpacity": "1",
                                    "stroke": "none",
                                    "strokeWidth": "3.17035532",
                                    "strokeLinecap": "round",
                                    "strokeLinejoin": "round",
                                    "strokeMiterlimit": "7.5",
                                    "strokeDasharray": "none",
                                    "strokeDashoffset": "0",
                                    "strokeOpacity": "1"
                                }}
                                      d="M 649.98198,250.46823 A 399.99148,399.54176 0 0 1 449.73516,596.62622 399.99148,399.54176 0 0 1 49.492951,596.19169 399.99148,399.54176 0 0 1 -150.00006,249.59973"/>
                                <path id="path2690" style={{
                                    "fill": "none",
                                    "stroke": "#ffffff",
                                    "strokeWidth": "6",
                                    "strokeLinecap": "butt",
                                    "strokeLinejoin": "miter",
                                    "strokeMiterlimit": "4",
                                    "strokeDasharray": "none",
                                    "strokeOpacity": "1"
                                }} d="m 650,250 c -266.66567,-0.002 -533.33233,-0.003 -800,-0.005"/>
                            </g>
                            <g id="g3277">
                                <path id="path2701" style={{
                                    "fill": "none",
                                    "stroke": "#ffffff",
                                    "strokeWidth": "4",
                                    "strokeLinecap": "butt",
                                    "strokeLinejoin": "miter",
                                    "strokeMiterlimit": "4",
                                    "strokeDasharray": "none",
                                    "strokeOpacity": "1"
                                }} d="m 275,232.972 c -16.66567,0 -33.33233,0 -50,0"/>
                                <path id="path2701-5" style={{
                                    "fill": "none",
                                    "stroke": "#ffffff",
                                    "strokeWidth": "3.99999976",
                                    "strokeLinecap": "butt",
                                    "strokeLinejoin": "miter",
                                    "strokeMiterlimit": "4",
                                    "strokeDasharray": "none",
                                    "strokeOpacity": "1"
                                }} d="m 300,217.2 c -33.33135,0 -66.66466,0 -100,0"/>
                                <path id="path2701-8" style={{
                                    "fill": "none",
                                    "stroke": "#ffffff",
                                    "strokeWidth": "4",
                                    "strokeLinecap": "butt",
                                    "strokeLinejoin": "miter",
                                    "strokeMiterlimit": "4",
                                    "strokeDasharray": "none",
                                    "strokeOpacity": "1"
                                }} d="m 275,201.272 c -16.66567,0 -33.33233,0 -50,0"/>
                                <path id="path2701-5-7" style={{
                                    "fill": "none",
                                    "stroke": "#ffffff",
                                    "strokeWidth": "3.99999976",
                                    "strokeLinecap": "butt",
                                    "strokeLinejoin": "miter",
                                    "strokeMiterlimit": "4",
                                    "strokeDasharray": "none",
                                    "strokeOpacity": "1"
                                }} d="m 300,185.5 c -33.33135,0 -66.66466,0 -100,0"/>
                                <path id="path2701-8-7" style={{
                                    "fill": "none",
                                    "stroke": "#ffffff",
                                    "strokeWidth": "4",
                                    "strokeLinecap": "butt",
                                    "strokeLinejoin": "miter",
                                    "strokeMiterlimit": "4",
                                    "strokeDasharray": "none",
                                    "strokeOpacity": "1"
                                }} d="m 275,169.7 c -16.66567,0 -33.33233,0 -50,0"/>
                                <path id="path2701-5-7-7" style={{
                                    "fill": "none",
                                    "stroke": "#ffffff",
                                    "strokeWidth": "3.99999976",
                                    "strokeLinecap": "butt",
                                    "strokeLinejoin": "miter",
                                    "strokeMiterlimit": "4",
                                    "strokeDasharray": "none",
                                    "strokeOpacity": "1"
                                }} d="m 300,153.928 c -33.33135,0 -66.66466,0 -100,0"/>
                                <path id="path2701-8-7-6" style={{
                                    "fill": "none",
                                    "stroke": "#ffffff",
                                    "strokeWidth": "4",
                                    "strokeLinecap": "butt",
                                    "strokeLinejoin": "miter",
                                    "strokeMiterlimit": "4",
                                    "strokeDasharray": "none",
                                    "strokeOpacity": "1"
                                }} d="m 275,137.872 c -16.66567,0 -33.33233,0 -50,0"/>
                                <path id="path2701-5-7-7-8" style={{
                                    "fill": "none",
                                    "stroke": "#ffffff",
                                    "strokeWidth": "3.99999976",
                                    "strokeLinecap": "butt",
                                    "strokeLinejoin": "miter",
                                    "strokeMiterlimit": "4",
                                    "strokeDasharray": "none",
                                    "strokeOpacity": "1"
                                }} d="m 300,122.1 c -33.33135,0 -66.66466,0 -100,0"/>
                                <path id="path2701-9" style={{
                                    "fill": "none",
                                    "stroke": "#ffffff",
                                    "strokeWidth": "4",
                                    "strokeLinecap": "butt",
                                    "strokeLinejoin": "miter",
                                    "strokeMiterlimit": "4",
                                    "strokeDasharray": "none",
                                    "strokeOpacity": "1"
                                }} d="m 275,267.1 c -16.66567,0 -33.33233,0 -50,0"/>
                                <path id="path2701-5-5" style={{
                                    "fill": "none",
                                    "stroke": "#ffffff",
                                    "strokeWidth": "3.99999976",
                                    "strokeLinecap": "butt",
                                    "strokeLinejoin": "miter",
                                    "strokeMiterlimit": "4",
                                    "strokeDasharray": "none",
                                    "strokeOpacity": "1"
                                }} d="m 300,282.872 c -33.33135,0 -66.66466,0 -100,0"/>
                                <path id="path2701-8-9" style={{
                                    "fill": "none",
                                    "stroke": "#ffffff",
                                    "strokeWidth": "4",
                                    "strokeLinecap": "butt",
                                    "strokeLinejoin": "miter",
                                    "strokeMiterlimit": "4",
                                    "strokeDasharray": "none",
                                    "strokeOpacity": "1"
                                }} d="m 275,298.8 c -16.66567,0 -33.33233,0 -50,0"/>
                                <path id="path2701-5-7-9" style={{
                                    "fill": "none",
                                    "stroke": "#ffffff",
                                    "strokeWidth": "3.99999976",
                                    "strokeLinecap": "butt",
                                    "strokeLinejoin": "miter",
                                    "strokeMiterlimit": "4",
                                    "strokeDasharray": "none",
                                    "strokeOpacity": "1"
                                }} d="m 300,314.572 c -33.33135,0 -66.66466,0 -100,0"/>
                                <path id="path2701-8-7-7" style={{
                                    "fill": "none",
                                    "stroke": "#ffffff",
                                    "strokeWidth": "4",
                                    "strokeLinecap": "butt",
                                    "strokeLinejoin": "miter",
                                    "strokeMiterlimit": "4",
                                    "strokeDasharray": "none",
                                    "strokeOpacity": "1"
                                }} d="m 275,330.372 c -16.66567,0 -33.33233,0 -50,0"/>
                                <path id="path2701-5-7-7-85" style={{
                                    "fill": "none",
                                    "stroke": "#ffffff",
                                    "strokeWidth": "3.99999976",
                                    "strokeLinecap": "butt",
                                    "strokeLinejoin": "miter",
                                    "strokeMiterlimit": "4",
                                    "strokeDasharray": "none",
                                    "strokeOpacity": "1"
                                }} d="m 300,346.144 c -33.33135,0 -66.66466,0 -100,0"/>
                                <path id="path2701-8-7-6-7" style={{
                                    "fill": "none",
                                    "stroke": "#ffffff",
                                    "strokeWidth": "4",
                                    "strokeLinecap": "butt",
                                    "strokeLinejoin": "miter",
                                    "strokeMiterlimit": "4",
                                    "strokeDasharray": "none",
                                    "strokeOpacity": "1"
                                }} d="m 275,362.2 c -16.66567,0 -33.33233,0 -50,0"/>
                                <path id="path2701-5-7-7-8-6" style={{
                                    "fill": "none",
                                    "stroke": "#ffffff",
                                    "strokeWidth": "3.99999976",
                                    "strokeLinecap": "butt",
                                    "strokeLinejoin": "miter",
                                    "strokeMiterlimit": "4",
                                    "strokeDasharray": "none",
                                    "strokeOpacity": "1"
                                }} d="m 300,377.972 c -33.33135,0 -66.66466,0 -100,0"/>
                                <g id="text2857" style={{
                                    "fontStyle": "normal",
                                    "fontWeight": "normal",
                                    "fontSize": "32px",
                                    "lineHeight": "1.25",
                                    "fontFamily": "sans-serif",
                                    "letterSpacing": "0px",
                                    "wordSpacing": "0px",
                                    "fill": "#000000",
                                    "fillOpacity": "1",
                                    "stroke": "none"
                                }}>
                                    <path id="path3124" style={{
                                        "fontStyle": "normal",
                                        "fontVariant": "normal",
                                        "fontWeight": "bold",
                                        "fontStretch": "normal",
                                        "fontSize": "21.33333397px",
                                        "fontFamily": "Calibri",
                                        "InkscapeFontSpecification": "'Calibri Bold'",
                                        "fill": "#ffffff"
                                    }}
                                          d="m 180.78367,222.90876 q 0,0.29166 -0.0312,0.5 -0.0312,0.19791 -0.0937,0.32291 -0.0521,0.11459 -0.125,0.16667 -0.0729,0.0521 -0.16667,0.0521 h -7.4375 q -0.0833,0 -0.15625,-0.0521 -0.0729,-0.0521 -0.13542,-0.16667 -0.0521,-0.125 -0.0833,-0.32291 -0.0312,-0.20834 -0.0312,-0.5 0,-0.30209 0.0208,-0.5 0.0312,-0.20834 0.0833,-0.33334 0.0625,-0.125 0.13541,-0.17708 0.0729,-0.0625 0.16667,-0.0625 h 2.51042 v -8.77083 l -2.16667,1.19791 q -0.23958,0.11459 -0.39583,0.14584 -0.14584,0.0208 -0.23959,-0.0625 -0.0833,-0.0937 -0.11458,-0.3125 -0.0312,-0.21875 -0.0312,-0.61459 0,-0.25 0.0104,-0.40625 0.0104,-0.16666 0.0521,-0.28125 0.0417,-0.11458 0.11458,-0.1875 0.0729,-0.0729 0.19792,-0.15625 l 2.89583,-1.875 q 0.0521,-0.0417 0.125,-0.0625 0.0833,-0.0312 0.20834,-0.0417 0.125,-0.0208 0.32291,-0.0208 0.20834,-0.0104 0.53125,-0.0104 0.39584,0 0.63542,0.0208 0.25,0.0104 0.375,0.0521 0.125,0.0312 0.16667,0.0937 0.0417,0.0625 0.0417,0.15625 v 11.13542 h 2.19792 q 0.0937,0 0.16667,0.0625 0.0833,0.0521 0.13541,0.17708 0.0625,0.125 0.0833,0.33334 0.0312,0.19791 0.0312,0.5 z"/>
                                    <path id="path3126" style={{
                                        "fontStyle": "normal",
                                        "fontVariant": "normal",
                                        "fontWeight": "bold",
                                        "fontStretch": "normal",
                                        "fontSize": "21.33333397px",
                                        "fontFamily": "Calibri",
                                        "InkscapeFontSpecification": "'Calibri Bold'",
                                        "fill": "#ffffff"
                                    }}
                                          d="m 192.01283,217.15876 q 0,1.61458 -0.26041,2.91666 -0.26042,1.30209 -0.85417,2.21875 -0.58333,0.91667 -1.53125,1.40625 -0.9375,0.48959 -2.30208,0.48959 -1.38542,0 -2.29167,-0.46875 -0.90625,-0.47917 -1.4375,-1.36459 -0.53125,-0.89583 -0.75,-2.17708 -0.20833,-1.29167 -0.20833,-2.91667 0,-1.60416 0.26041,-2.90625 0.27084,-1.3125 0.85417,-2.22916 0.59375,-0.91667 1.53125,-1.40625 0.94792,-0.48959 2.30208,-0.48959 1.38542,0 2.29167,0.47917 0.91667,0.46875 1.44792,1.36458 0.53125,0.88542 0.73958,2.17709 0.20833,1.28125 0.20833,2.90625 z m -2.76041,0.13541 q 0,-0.95833 -0.0521,-1.6875 -0.0521,-0.73958 -0.16666,-1.28125 -0.10417,-0.54166 -0.27084,-0.91666 -0.15625,-0.375 -0.38541,-0.59375 -0.22917,-0.22917 -0.52084,-0.32292 -0.29166,-0.0937 -0.64583,-0.0937 -0.61458,0 -1.02083,0.30208 -0.39584,0.29167 -0.63542,0.88542 -0.22917,0.59375 -0.32292,1.47917 -0.0937,0.88541 -0.0937,2.0625 0,1.4375 0.11459,2.38541 0.11458,0.9375 0.35416,1.5 0.25,0.55209 0.63542,0.78125 0.38542,0.21875 0.92708,0.21875 0.40625,0 0.71875,-0.125 0.3125,-0.13541 0.54167,-0.39583 0.23958,-0.26042 0.39583,-0.65625 0.15625,-0.39583 0.25,-0.91667 0.10417,-0.52083 0.13542,-1.17708 0.0417,-0.65625 0.0417,-1.44792 z"/>
                                </g>
                                <g id="text2857-2" style={{
                                    "fontStyle": "normal",
                                    "fontWeight": "normal",
                                    "fontSize": "32px",
                                    "lineHeight": "1.25",
                                    "fontFamily": "sans-serif",
                                    "letterSpacing": "0px",
                                    "wordSpacing": "0px",
                                    "fill": "#000000",
                                    "fillOpacity": "1",
                                    "stroke": "none"
                                }}>
                                    <path id="path3185" style={{
                                        "fontStyle": "normal",
                                        "fontVariant": "normal",
                                        "fontWeight": "bold",
                                        "fontStretch": "normal",
                                        "fontSize": "21.33333397px",
                                        "fontFamily": "Calibri",
                                        "InkscapeFontSpecification": "'Calibri Bold'",
                                        "fill": "#ffffff"
                                    }}
                                          d="m 316.28365,222.93375 q 0,0.29167 -0.0312,0.5 -0.0312,0.19792 -0.0937,0.32292 -0.0521,0.11458 -0.125,0.16666 -0.0729,0.0521 -0.16667,0.0521 h -7.4375 q -0.0833,0 -0.15625,-0.0521 -0.0729,-0.0521 -0.13541,-0.16666 -0.0521,-0.125 -0.0833,-0.32292 -0.0312,-0.20833 -0.0312,-0.5 0,-0.30208 0.0208,-0.5 0.0312,-0.20833 0.0833,-0.33333 0.0625,-0.125 0.13542,-0.17709 0.0729,-0.0625 0.16666,-0.0625 h 2.51042 V 213.09 l -2.16667,1.19792 q -0.23958,0.11458 -0.39583,0.14583 -0.14583,0.0208 -0.23958,-0.0625 -0.0833,-0.0937 -0.11459,-0.3125 -0.0312,-0.21875 -0.0312,-0.61458 0,-0.25 0.0104,-0.40625 0.0104,-0.16667 0.0521,-0.28125 0.0417,-0.11459 0.11459,-0.1875 0.0729,-0.0729 0.19791,-0.15625 l 2.89584,-1.875 q 0.0521,-0.0417 0.125,-0.0625 0.0833,-0.0312 0.20833,-0.0417 0.125,-0.0208 0.32292,-0.0208 0.20833,-0.0104 0.53125,-0.0104 0.39583,0 0.63541,0.0208 0.25,0.0104 0.375,0.0521 0.125,0.0312 0.16667,0.0937 0.0417,0.0625 0.0417,0.15625 v 11.13541 h 2.19791 q 0.0937,0 0.16667,0.0625 0.0833,0.0521 0.13542,0.17709 0.0625,0.125 0.0833,0.33333 0.0312,0.19792 0.0312,0.5 z"/>
                                    <path id="path3187" style={{
                                        "fontStyle": "normal",
                                        "fontVariant": "normal",
                                        "fontWeight": "bold",
                                        "fontStretch": "normal",
                                        "fontSize": "21.33333397px",
                                        "fontFamily": "Calibri",
                                        "InkscapeFontSpecification": "'Calibri Bold'",
                                        "fill": "#ffffff"
                                    }}
                                          d="m 327.51282,217.18375 q 0,1.61458 -0.26042,2.91667 -0.26042,1.30208 -0.85417,2.21875 -0.58333,0.91666 -1.53125,1.40625 -0.9375,0.48958 -2.30208,0.48958 -1.38542,0 -2.29167,-0.46875 -0.90625,-0.47917 -1.4375,-1.36458 -0.53125,-0.89584 -0.75,-2.17709 -0.20833,-1.29166 -0.20833,-2.91666 0,-1.60417 0.26042,-2.90625 0.27083,-1.3125 0.85416,-2.22917 0.59375,-0.91667 1.53125,-1.40625 0.94792,-0.48958 2.30209,-0.48958 1.38541,0 2.29166,0.47916 0.91667,0.46875 1.44792,1.36459 0.53125,0.88541 0.73958,2.17708 0.20834,1.28125 0.20834,2.90625 z m -2.76042,0.13542 q 0,-0.95834 -0.0521,-1.6875 -0.0521,-0.73959 -0.16667,-1.28125 -0.10417,-0.54167 -0.27083,-0.91667 -0.15625,-0.375 -0.38542,-0.59375 -0.22917,-0.22917 -0.52083,-0.32292 -0.29167,-0.0937 -0.64584,-0.0937 -0.61458,0 -1.02083,0.30209 -0.39583,0.29166 -0.63542,0.88541 -0.22916,0.59375 -0.32291,1.47917 -0.0937,0.88542 -0.0937,2.0625 0,1.4375 0.11458,2.38542 0.11458,0.9375 0.35417,1.5 0.25,0.55208 0.63541,0.78125 0.38542,0.21875 0.92709,0.21875 0.40625,0 0.71875,-0.125 0.3125,-0.13542 0.54166,-0.39584 0.23959,-0.26041 0.39584,-0.65625 0.15625,-0.39583 0.25,-0.91666 0.10416,-0.52084 0.13541,-1.17709 0.0417,-0.65625 0.0417,-1.44791 z"/>
                                </g>
                                <g id="text2857-24" style={{
                                    "fontStyle": "normal",
                                    "fontWeight": "normal",
                                    "fontSize": "32px",
                                    "lineHeight": "1.25",
                                    "fontFamily": "sans-serif",
                                    "letterSpacing": "0px",
                                    "wordSpacing": "0px",
                                    "fill": "#000000",
                                    "fillOpacity": "1",
                                    "stroke": "none"
                                }}>
                                    <path id="path3119" style={{
                                        "fontStyle": "normal",
                                        "fontVariant": "normal",
                                        "fontWeight": "bold",
                                        "fontStretch": "normal",
                                        "fontSize": "21.33333397px",
                                        "fontFamily": "Calibri",
                                        "InkscapeFontSpecification": "'Calibri Bold'",
                                        "fill": "#ffffff"
                                    }}
                                          d="m 180.83167,191.12499 q 0,0.30209 -0.0312,0.52084 -0.0208,0.20833 -0.0729,0.34375 -0.0521,0.13541 -0.13541,0.19791 -0.0833,0.0521 -0.1875,0.0521 h -7.75 q -0.22917,0 -0.39584,-0.0417 -0.16666,-0.0417 -0.27083,-0.15625 -0.10417,-0.125 -0.15625,-0.35417 -0.0417,-0.22916 -0.0417,-0.59375 0,-0.34375 0.0312,-0.58333 0.0312,-0.25 0.11459,-0.4375 0.0833,-0.19792 0.20833,-0.375 0.13542,-0.1875 0.34375,-0.40625 l 2.33333,-2.5 q 0.69792,-0.72917 1.125,-1.32292 0.42709,-0.60416 0.66667,-1.09375 0.23958,-0.5 0.32292,-0.91666 0.0937,-0.41667 0.0937,-0.79167 0,-0.34375 -0.11459,-0.64583 -0.10416,-0.3125 -0.32291,-0.54167 -0.20834,-0.22917 -0.53125,-0.35417 -0.32292,-0.13541 -0.76042,-0.13541 -0.61458,0 -1.09375,0.15625 -0.46875,0.15625 -0.83333,0.35416 -0.35417,0.1875 -0.59375,0.35417 -0.23959,0.15625 -0.375,0.15625 -0.0937,0 -0.16667,-0.0625 -0.0625,-0.0625 -0.10417,-0.20833 -0.0417,-0.14584 -0.0729,-0.38542 -0.0208,-0.25 -0.0208,-0.60417 0,-0.23958 0.0104,-0.39583 0.0208,-0.16667 0.0521,-0.28125 0.0312,-0.125 0.0833,-0.20833 0.0521,-0.0937 0.17708,-0.21875 0.13542,-0.125 0.47917,-0.3125 0.35416,-0.19792 0.86458,-0.375 0.51042,-0.1875 1.125,-0.3125 0.61458,-0.125 1.28125,-0.125 1.05208,0 1.83333,0.27083 0.79167,0.26042 1.3125,0.73958 0.52084,0.46875 0.77084,1.125 0.26041,0.64584 0.26041,1.39584 0,0.65625 -0.125,1.29166 -0.125,0.63542 -0.52083,1.375 -0.39583,0.72917 -1.11458,1.625 -0.71875,0.88542 -1.90625,2.0625 l -1.57292,1.61459 h 5.3125 q 0.10417,0 0.1875,0.0625 0.0937,0.0625 0.15625,0.19791 0.0625,0.125 0.0937,0.34375 0.0312,0.20834 0.0312,0.5 z"/>
                                    <path id="path3121" style={{
                                        "fontStyle": "normal",
                                        "fontVariant": "normal",
                                        "fontWeight": "bold",
                                        "fontStretch": "normal",
                                        "fontSize": "21.33333397px",
                                        "fontFamily": "Calibri",
                                        "InkscapeFontSpecification": "'Calibri Bold'",
                                        "fill": "#ffffff"
                                    }}
                                          d="m 191.93584,185.44791 q 0,1.61458 -0.26042,2.91667 -0.26042,1.30208 -0.85417,2.21875 -0.58333,0.91666 -1.53125,1.40625 -0.9375,0.48958 -2.30208,0.48958 -1.38542,0 -2.29167,-0.46875 -0.90625,-0.47917 -1.4375,-1.36458 -0.53125,-0.89584 -0.75,-2.17709 -0.20833,-1.29166 -0.20833,-2.91666 0,-1.60417 0.26042,-2.90625 0.27083,-1.3125 0.85416,-2.22917 0.59375,-0.91667 1.53125,-1.40625 0.94792,-0.48958 2.30209,-0.48958 1.38541,0 2.29166,0.47916 0.91667,0.46875 1.44792,1.36459 0.53125,0.88541 0.73958,2.17708 0.20834,1.28125 0.20834,2.90625 z m -2.76042,0.13542 q 0,-0.95834 -0.0521,-1.6875 -0.0521,-0.73959 -0.16667,-1.28125 -0.10417,-0.54167 -0.27083,-0.91667 -0.15625,-0.375 -0.38542,-0.59375 -0.22917,-0.22917 -0.52083,-0.32292 -0.29167,-0.0937 -0.64584,-0.0937 -0.61458,0 -1.02083,0.30209 -0.39583,0.29166 -0.63542,0.88541 -0.22916,0.59375 -0.32291,1.47917 -0.0937,0.88542 -0.0937,2.0625 0,1.4375 0.11458,2.38542 0.11458,0.9375 0.35417,1.5 0.25,0.55208 0.63541,0.78125 0.38542,0.21875 0.92709,0.21875 0.40625,0 0.71875,-0.125 0.3125,-0.13542 0.54166,-0.39584 0.23959,-0.26041 0.39584,-0.65625 0.15625,-0.39583 0.25,-0.91666 0.10416,-0.52084 0.13541,-1.17709 0.0417,-0.65625 0.0417,-1.44791 z"/>
                                </g>
                                <g id="text2857-24-5" style={{
                                    "fontStyle": "normal",
                                    "fontWeight": "normal",
                                    "fontSize": "32px",
                                    "lineHeight": "1.25",
                                    "fontFamily": "sans-serif",
                                    "letterSpacing": "0px",
                                    "wordSpacing": "0px",
                                    "fill": "#000000",
                                    "fillOpacity": "1",
                                    "stroke": "none"
                                }}>
                                    <path id="path3114" style={{
                                        "fontStyle": "normal",
                                        "fontVariant": "normal",
                                        "fontWeight": "bold",
                                        "fontStretch": "normal",
                                        "fontSize": "21.33333397px",
                                        "fontFamily": "Calibri",
                                        "InkscapeFontSpecification": "'Calibri Bold'",
                                        "fill": "#ffffff"
                                    }}
                                          d="m 180.72117,156.7515 q 0,1.01042 -0.38542,1.79167 -0.38542,0.78125 -1.07292,1.3125 -0.6875,0.53125 -1.64583,0.8125 -0.95833,0.27083 -2.09375,0.27083 -0.6875,0 -1.29167,-0.10417 -0.60416,-0.0937 -1.07291,-0.23958 -0.45834,-0.14583 -0.76042,-0.30208 -0.30208,-0.15625 -0.39583,-0.23959 -0.0937,-0.0833 -0.14584,-0.1875 -0.0417,-0.10416 -0.0833,-0.23958 -0.0312,-0.14583 -0.0521,-0.35417 -0.0104,-0.21875 -0.0104,-0.52083 0,-0.5 0.0833,-0.6875 0.0833,-0.19792 0.25,-0.19792 0.10417,0 0.35417,0.14584 0.26042,0.13541 0.65625,0.30208 0.39583,0.15625 0.92708,0.30208 0.53125,0.13542 1.20834,0.13542 0.57291,0 1.01041,-0.13542 0.4375,-0.13541 0.73959,-0.375 0.3125,-0.25 0.45833,-0.59375 0.15625,-0.35416 0.15625,-0.78125 0,-0.46875 -0.1875,-0.84375 -0.17708,-0.375 -0.54167,-0.63541 -0.35416,-0.27084 -0.90625,-0.41667 -0.54166,-0.14583 -1.28125,-0.14583 h -1.16666 q -0.13542,0 -0.22917,-0.0312 -0.0937,-0.0417 -0.15625,-0.15625 -0.0625,-0.11459 -0.0937,-0.3125 -0.0208,-0.20834 -0.0208,-0.53125 0,-0.30209 0.0208,-0.48959 0.0312,-0.19791 0.0833,-0.30208 0.0625,-0.10417 0.14584,-0.14583 0.0937,-0.0417 0.21875,-0.0417 h 1.17708 q 0.60417,0 1.07292,-0.13542 0.46875,-0.14583 0.78125,-0.40625 0.32291,-0.26041 0.48958,-0.625 0.16667,-0.375 0.16667,-0.82291 0,-0.34375 -0.11459,-0.64584 -0.11458,-0.3125 -0.34375,-0.53125 -0.21875,-0.22916 -0.57291,-0.35416 -0.35417,-0.13542 -0.83334,-0.13542 -0.54166,0 -1.02083,0.16667 -0.47917,0.15625 -0.86458,0.35416 -0.375,0.1875 -0.64584,0.35417 -0.26041,0.16667 -0.38541,0.16667 -0.0833,0 -0.14584,-0.0312 -0.0625,-0.0417 -0.10416,-0.14584 -0.0417,-0.10416 -0.0625,-0.30208 -0.0208,-0.19792 -0.0208,-0.51042 0,-0.26041 0.0104,-0.42708 0.0104,-0.17708 0.0417,-0.29167 0.0312,-0.11458 0.0729,-0.19791 0.0521,-0.0833 0.15625,-0.17709 0.10417,-0.10416 0.42709,-0.30208 0.32291,-0.19792 0.8125,-0.38542 0.48958,-0.1875 1.125,-0.3125 0.64583,-0.13541 1.39583,-0.13541 0.97917,0 1.72917,0.22916 0.76041,0.22917 1.27083,0.66667 0.52083,0.42708 0.78125,1.0625 0.27083,0.625 0.27083,1.41667 0,0.61458 -0.15625,1.14583 -0.15625,0.53125 -0.45833,0.94792 -0.30208,0.41666 -0.76042,0.70833 -0.44791,0.29167 -1.04166,0.4375 v 0.0312 q 0.70833,0.0833 1.27083,0.36458 0.5625,0.27084 0.94792,0.6875 0.39583,0.41667 0.60416,0.94792 0.20834,0.52083 0.20834,1.125 z"/>
                                    <path id="path3116" style={{
                                        "fontStyle": "normal",
                                        "fontVariant": "normal",
                                        "fontWeight": "bold",
                                        "fontStretch": "normal",
                                        "fontSize": "21.33333397px",
                                        "fontFamily": "Calibri",
                                        "InkscapeFontSpecification": "'Calibri Bold'",
                                        "fill": "#ffffff"
                                    }}
                                          d="m 191.88783,153.90775 q 0,1.61458 -0.26041,2.91667 -0.26042,1.30208 -0.85417,2.21875 -0.58333,0.91666 -1.53125,1.40625 -0.9375,0.48958 -2.30208,0.48958 -1.38542,0 -2.29167,-0.46875 -0.90625,-0.47917 -1.4375,-1.36458 -0.53125,-0.89584 -0.75,-2.17709 -0.20833,-1.29166 -0.20833,-2.91666 0,-1.60417 0.26041,-2.90625 0.27084,-1.3125 0.85417,-2.22917 0.59375,-0.91667 1.53125,-1.40625 0.94792,-0.48958 2.30208,-0.48958 1.38542,0 2.29167,0.47916 0.91667,0.46875 1.44792,1.36459 0.53125,0.88541 0.73958,2.17708 0.20833,1.28125 0.20833,2.90625 z m -2.76041,0.13542 q 0,-0.95834 -0.0521,-1.6875 -0.0521,-0.73959 -0.16666,-1.28125 -0.10417,-0.54167 -0.27084,-0.91667 -0.15625,-0.375 -0.38541,-0.59375 -0.22917,-0.22917 -0.52084,-0.32292 -0.29166,-0.0937 -0.64583,-0.0937 -0.61458,0 -1.02083,0.30209 -0.39584,0.29166 -0.63542,0.88541 -0.22917,0.59375 -0.32292,1.47917 -0.0937,0.88542 -0.0937,2.0625 0,1.4375 0.11459,2.38542 0.11458,0.9375 0.35416,1.5 0.25,0.55208 0.63542,0.78125 0.38542,0.21875 0.92708,0.21875 0.40625,0 0.71875,-0.125 0.3125,-0.13542 0.54167,-0.39584 0.23958,-0.26041 0.39583,-0.65625 0.15625,-0.39583 0.25,-0.91666 0.10417,-0.52084 0.13542,-1.17709 0.0417,-0.65625 0.0417,-1.44791 z"/>
                                </g>
                                <g id="text2857-24-5-1" style={{
                                    "fontStyle": "normal",
                                    "fontWeight": "normal",
                                    "fontSize": "32px",
                                    "lineHeight": "1.25",
                                    "fontFamily": "sans-serif",
                                    "letterSpacing": "0px",
                                    "wordSpacing": "0px",
                                    "fill": "#000000",
                                    "fillOpacity": "1",
                                    "stroke": "none"
                                }}>
                                    <path id="path3105" style={{
                                        "fontStyle": "normal",
                                        "fontVariant": "normal",
                                        "fontWeight": "bold",
                                        "fontStretch": "normal",
                                        "fontSize": "21.33333397px",
                                        "fontFamily": "Calibri",
                                        "InkscapeFontSpecification": "'Calibri Bold'",
                                        "fill": "#ffffff"
                                    }}
                                          d="m 181.29733,124.92442 q 0,0.53125 -0.11458,0.8125 -0.10417,0.27084 -0.29167,0.27084 h -1.19791 v 2.4375 q 0,0.10416 -0.0625,0.1875 -0.0625,0.0729 -0.21875,0.125 -0.15625,0.0521 -0.40625,0.0729 -0.25,0.0312 -0.64584,0.0312 -0.375,0 -0.63541,-0.0312 -0.25,-0.0208 -0.40625,-0.0729 -0.14584,-0.0521 -0.20834,-0.125 -0.0521,-0.0833 -0.0521,-0.1875 v -2.4375 h -5.15625 q -0.14583,0 -0.26042,-0.0312 -0.11458,-0.0417 -0.19791,-0.16667 -0.0729,-0.13542 -0.11459,-0.375 -0.0312,-0.25 -0.0312,-0.65625 0,-0.33333 0.0104,-0.57292 0.0208,-0.25 0.0521,-0.44791 0.0417,-0.19792 0.10417,-0.375 0.0729,-0.17709 0.17708,-0.375 l 4.1875,-7.38542 q 0.0521,-0.0937 0.17709,-0.15625 0.125,-0.0729 0.34375,-0.11458 0.22916,-0.0521 0.57291,-0.0729 0.34375,-0.0208 0.83334,-0.0208 0.53125,0 0.90625,0.0312 0.375,0.0208 0.59375,0.0833 0.22916,0.0521 0.33333,0.13542 0.10417,0.0833 0.10417,0.19791 v 8.11459 h 1.19791 q 0.16667,0 0.28125,0.26041 0.125,0.25 0.125,0.84375 z m -4.23958,-7.30208 h -0.0208 l -3.55209,6.19792 h 3.57292 z"/>
                                    <path id="path3107" style={{
                                        "fontStyle": "normal",
                                        "fontVariant": "normal",
                                        "fontWeight": "bold",
                                        "fontStretch": "normal",
                                        "fontSize": "21.33333397px",
                                        "fontFamily": "Calibri",
                                        "InkscapeFontSpecification": "'Calibri Bold'",
                                        "fill": "#ffffff"
                                    }}
                                          d="m 191.98483,122.00776 q 0,1.61458 -0.26041,2.91666 -0.26042,1.30209 -0.85417,2.21875 -0.58333,0.91667 -1.53125,1.40625 -0.9375,0.48959 -2.30208,0.48959 -1.38542,0 -2.29167,-0.46875 -0.90625,-0.47917 -1.4375,-1.36459 -0.53125,-0.89583 -0.75,-2.17708 -0.20833,-1.29167 -0.20833,-2.91667 0,-1.60416 0.26041,-2.90625 0.27084,-1.3125 0.85417,-2.22916 0.59375,-0.91667 1.53125,-1.40625 0.94792,-0.48959 2.30208,-0.48959 1.38542,0 2.29167,0.47917 0.91667,0.46875 1.44792,1.36458 0.53125,0.88542 0.73958,2.17709 0.20833,1.28125 0.20833,2.90625 z m -2.76041,0.13541 q 0,-0.95833 -0.0521,-1.6875 -0.0521,-0.73958 -0.16666,-1.28125 -0.10417,-0.54166 -0.27084,-0.91666 -0.15625,-0.375 -0.38541,-0.59375 -0.22917,-0.22917 -0.52084,-0.32292 -0.29166,-0.0937 -0.64583,-0.0937 -0.61458,0 -1.02083,0.30208 -0.39584,0.29167 -0.63542,0.88542 -0.22917,0.59375 -0.32292,1.47917 -0.0937,0.88541 -0.0937,2.0625 0,1.4375 0.11459,2.38541 0.11458,0.9375 0.35416,1.5 0.25,0.55209 0.63542,0.78125 0.38542,0.21875 0.92708,0.21875 0.40625,0 0.71875,-0.125 0.3125,-0.13541 0.54167,-0.39583 0.23958,-0.26042 0.39583,-0.65625 0.15625,-0.39583 0.25,-0.91667 0.10417,-0.52083 0.13542,-1.17708 0.0417,-0.65625 0.0417,-1.44792 z"/>
                                </g>
                                <g id="text2857-24-2" style={{
                                    "fontStyle": "normal",
                                    "fontWeight": "normal",
                                    "fontSize": "32px",
                                    "lineHeight": "1.25",
                                    "fontFamily": "sans-serif",
                                    "letterSpacing": "0px",
                                    "wordSpacing": "0px",
                                    "fill": "#000000",
                                    "fillOpacity": "1",
                                    "stroke": "none"
                                }}>
                                    <path id="path3190" style={{
                                        "fontStyle": "normal",
                                        "fontVariant": "normal",
                                        "fontWeight": "bold",
                                        "fontStretch": "normal",
                                        "fontSize": "21.33333397px",
                                        "fontFamily": "Calibri",
                                        "InkscapeFontSpecification": "'Calibri Bold'",
                                        "fill": "#ffffff"
                                    }}
                                          d="m 317.11565,191.11883 q 0,0.30208 -0.0312,0.52083 -0.0208,0.20834 -0.0729,0.34375 -0.0521,0.13542 -0.13542,0.19792 -0.0833,0.0521 -0.1875,0.0521 h -7.75 q -0.22917,0 -0.39584,-0.0417 -0.16666,-0.0417 -0.27083,-0.15625 -0.10417,-0.125 -0.15625,-0.35417 -0.0417,-0.22917 -0.0417,-0.59375 0,-0.34375 0.0312,-0.58333 0.0312,-0.25 0.11459,-0.4375 0.0833,-0.19792 0.20833,-0.375 0.13542,-0.1875 0.34375,-0.40625 l 2.33333,-2.5 q 0.69792,-0.72917 1.125,-1.32292 0.42709,-0.60417 0.66667,-1.09375 0.23958,-0.5 0.32292,-0.91667 0.0937,-0.41666 0.0937,-0.79166 0,-0.34375 -0.11459,-0.64584 -0.10416,-0.3125 -0.32291,-0.54166 -0.20834,-0.22917 -0.53125,-0.35417 -0.32292,-0.13542 -0.76042,-0.13542 -0.61458,0 -1.09375,0.15625 -0.46875,0.15625 -0.83333,0.35417 -0.35417,0.1875 -0.59375,0.35417 -0.23959,0.15625 -0.375,0.15625 -0.0937,0 -0.16667,-0.0625 -0.0625,-0.0625 -0.10417,-0.20834 -0.0417,-0.14583 -0.0729,-0.38541 -0.0208,-0.25 -0.0208,-0.60417 0,-0.23958 0.0104,-0.39583 0.0208,-0.16667 0.0521,-0.28125 0.0312,-0.125 0.0833,-0.20834 0.0521,-0.0937 0.17708,-0.21875 0.13542,-0.125 0.47917,-0.3125 0.35416,-0.19791 0.86458,-0.375 0.51042,-0.1875 1.125,-0.3125 0.61458,-0.125 1.28125,-0.125 1.05208,0 1.83333,0.27084 0.79167,0.26041 1.31251,0.73958 0.52083,0.46875 0.77083,1.125 0.26042,0.64583 0.26042,1.39583 0,0.65625 -0.125,1.29167 -0.125,0.63542 -0.52084,1.375 -0.39583,0.72917 -1.11458,1.625 -0.71875,0.88542 -1.90625,2.0625 l -1.57292,1.61458 h 5.3125 q 0.10417,0 0.1875,0.0625 0.0937,0.0625 0.15625,0.19792 0.0625,0.125 0.0937,0.34375 0.0312,0.20833 0.0312,0.5 z"/>
                                    <path id="path3192" style={{
                                        "fontStyle": "normal",
                                        "fontVariant": "normal",
                                        "fontWeight": "bold",
                                        "fontStretch": "normal",
                                        "fontSize": "21.33333397px",
                                        "fontFamily": "Calibri",
                                        "InkscapeFontSpecification": "'Calibri Bold'",
                                        "fill": "#ffffff"
                                    }}
                                          d="m 328.21982,185.44175 q 0,1.61458 -0.26042,2.91666 -0.26041,1.30209 -0.85416,2.21875 -0.58334,0.91667 -1.53125,1.40625 -0.9375,0.48959 -2.30209,0.48959 -1.38541,0 -2.29166,-0.46875 -0.90625,-0.47917 -1.4375,-1.36459 -0.53125,-0.89583 -0.75,-2.17708 -0.20834,-1.29167 -0.20834,-2.91667 0,-1.60416 0.26042,-2.90625 0.27083,-1.3125 0.85417,-2.22916 0.59375,-0.91667 1.53125,-1.40625 0.94791,-0.48959 2.30208,-0.48959 1.38542,0 2.29167,0.47917 0.91666,0.46875 1.44791,1.36458 0.53125,0.88542 0.73959,2.17709 0.20833,1.28125 0.20833,2.90625 z m -2.76042,0.13541 q 0,-0.95833 -0.0521,-1.6875 -0.0521,-0.73958 -0.16667,-1.28125 -0.10416,-0.54166 -0.27083,-0.91666 -0.15625,-0.375 -0.38542,-0.59375 -0.22916,-0.22917 -0.52083,-0.32292 -0.29167,-0.0937 -0.64583,-0.0937 -0.61459,0 -1.02084,0.30208 -0.39583,0.29167 -0.63541,0.88542 -0.22917,0.59375 -0.32292,1.47917 -0.0937,0.88541 -0.0937,2.0625 0,1.4375 0.11458,2.38541 0.11459,0.9375 0.35417,1.5 0.25,0.55209 0.63542,0.78125 0.38541,0.21875 0.92708,0.21875 0.40625,0 0.71875,-0.125 0.3125,-0.13541 0.54167,-0.39583 0.23958,-0.26042 0.39583,-0.65625 0.15625,-0.39583 0.25,-0.91667 0.10417,-0.52083 0.13542,-1.17708 0.0417,-0.65625 0.0417,-1.44792 z"/>
                                </g>
                                <g id="text2857-24-5-17" style={{
                                    "fontStyle": "normal",
                                    "fontWeight": "normal",
                                    "fontSize": "32px",
                                    "lineHeight": "1.25",
                                    "fontFamily": "sans-serif",
                                    "letterSpacing": "0px",
                                    "wordSpacing": "0px",
                                    "fill": "#000000",
                                    "fillOpacity": "1",
                                    "stroke": "none"
                                }}>
                                    <path id="path3195" style={{
                                        "fontStyle": "normal",
                                        "fontVariant": "normal",
                                        "fontWeight": "bold",
                                        "fontStretch": "normal",
                                        "fontSize": "21.33333397px",
                                        "fontFamily": "Calibri",
                                        "InkscapeFontSpecification": "'Calibri Bold'",
                                        "fill": "#ffffff"
                                    }}
                                          d="m 317.07543,156.68351 q 0,1.01041 -0.38542,1.79166 -0.38541,0.78125 -1.07291,1.3125 -0.6875,0.53125 -1.64584,0.8125 -0.95833,0.27084 -2.09375,0.27084 -0.6875,0 -1.29166,-0.10417 -0.60417,-0.0937 -1.07292,-0.23958 -0.45833,-0.14584 -0.76042,-0.30209 -0.30208,-0.15625 -0.39583,-0.23958 -0.0937,-0.0833 -0.14583,-0.1875 -0.0417,-0.10417 -0.0833,-0.23958 -0.0312,-0.14584 -0.0521,-0.35417 -0.0104,-0.21875 -0.0104,-0.52083 0,-0.5 0.0833,-0.6875 0.0833,-0.19792 0.25,-0.19792 0.10416,0 0.35416,0.14583 0.26042,0.13542 0.65625,0.30209 0.39584,0.15625 0.92709,0.30208 0.53125,0.13542 1.20833,0.13542 0.57292,0 1.01042,-0.13542 0.4375,-0.13542 0.73958,-0.375 0.3125,-0.25 0.45833,-0.59375 0.15625,-0.35417 0.15625,-0.78125 0,-0.46875 -0.1875,-0.84375 -0.17708,-0.375 -0.54166,-0.63542 -0.35417,-0.27083 -0.90625,-0.41666 -0.54167,-0.14584 -1.28125,-0.14584 h -1.16667 q -0.13542,0 -0.22917,-0.0312 -0.0937,-0.0417 -0.15625,-0.15625 -0.0625,-0.11458 -0.0937,-0.3125 -0.0208,-0.20833 -0.0208,-0.53125 0,-0.30208 0.0208,-0.48958 0.0312,-0.19792 0.0833,-0.30208 0.0625,-0.10417 0.14583,-0.14584 0.0937,-0.0417 0.21875,-0.0417 h 1.17708 q 0.60417,0 1.07292,-0.13542 0.46875,-0.14583 0.78125,-0.40625 0.32292,-0.26042 0.48958,-0.625 0.16667,-0.375 0.16667,-0.82292 0,-0.34375 -0.11458,-0.64583 -0.11459,-0.3125 -0.34375,-0.53125 -0.21875,-0.22917 -0.57292,-0.35417 -0.35417,-0.13541 -0.83333,-0.13541 -0.54167,0 -1.02084,0.16666 -0.47916,0.15625 -0.86458,0.35417 -0.375,0.1875 -0.64583,0.35417 -0.26042,0.16666 -0.38542,0.16666 -0.0833,0 -0.14583,-0.0312 -0.0625,-0.0417 -0.10417,-0.14583 -0.0417,-0.10417 -0.0625,-0.30208 -0.0208,-0.19792 -0.0208,-0.51042 0,-0.26042 0.0104,-0.42708 0.0104,-0.17709 0.0417,-0.29167 0.0312,-0.11458 0.0729,-0.19792 0.0521,-0.0833 0.15625,-0.17708 0.10416,-0.10417 0.42708,-0.30208 0.32292,-0.19792 0.8125,-0.38542 0.48958,-0.1875 1.125,-0.3125 0.64583,-0.13542 1.39583,-0.13542 0.97917,0 1.72917,0.22917 0.76042,0.22917 1.27083,0.66667 0.52084,0.42708 0.78125,1.0625 0.27084,0.625 0.27084,1.41666 0,0.61459 -0.15625,1.14584 -0.15625,0.53125 -0.45834,0.94791 -0.30208,0.41667 -0.76041,0.70834 -0.44792,0.29166 -1.04167,0.4375 v 0.0312 q 0.70833,0.0833 1.27083,0.36458 0.5625,0.27083 0.94792,0.6875 0.39583,0.41667 0.60417,0.94792 0.20833,0.52083 0.20833,1.125 z"/>
                                    <path id="path3197" style={{
                                        "fontStyle": "normal",
                                        "fontVariant": "normal",
                                        "fontWeight": "bold",
                                        "fontStretch": "normal",
                                        "fontSize": "21.33333397px",
                                        "fontFamily": "Calibri",
                                        "InkscapeFontSpecification": "'Calibri Bold'",
                                        "fill": "#ffffff"
                                    }}
                                          d="m 328.2421,153.83976 q 0,1.61458 -0.26042,2.91666 -0.26042,1.30209 -0.85417,2.21875 -0.58333,0.91667 -1.53125,1.40625 -0.9375,0.48959 -2.30208,0.48959 -1.38542,0 -2.29167,-0.46875 -0.90625,-0.47917 -1.4375,-1.36459 -0.53125,-0.89583 -0.75,-2.17708 -0.20833,-1.29167 -0.20833,-2.91667 0,-1.60416 0.26042,-2.90625 0.27083,-1.3125 0.85416,-2.22916 0.59375,-0.91667 1.53125,-1.40625 0.94792,-0.48959 2.30209,-0.48959 1.38541,0 2.29166,0.47917 0.91667,0.46875 1.44792,1.36458 0.53125,0.88542 0.73958,2.17709 0.20834,1.28125 0.20834,2.90625 z m -2.76042,0.13541 q 0,-0.95833 -0.0521,-1.6875 -0.0521,-0.73958 -0.16667,-1.28125 -0.10417,-0.54166 -0.27083,-0.91666 -0.15625,-0.375 -0.38542,-0.59375 -0.22917,-0.22917 -0.52083,-0.32292 -0.29167,-0.0937 -0.64584,-0.0937 -0.61458,0 -1.02083,0.30208 -0.39583,0.29167 -0.63542,0.88542 -0.22916,0.59375 -0.32291,1.47917 -0.0937,0.88541 -0.0937,2.0625 0,1.4375 0.11458,2.38541 0.11458,0.9375 0.35417,1.5 0.25,0.55209 0.63541,0.78125 0.38542,0.21875 0.92709,0.21875 0.40625,0 0.71875,-0.125 0.3125,-0.13541 0.54166,-0.39583 0.23959,-0.26042 0.39584,-0.65625 0.15625,-0.39583 0.25,-0.91667 0.10416,-0.52083 0.13541,-1.17708 0.0417,-0.65625 0.0417,-1.44792 z"/>
                                </g>
                                <g id="text2857-24-5-1-7" style={{
                                    "fontStyle": "normal",
                                    "fontWeight": "normal",
                                    "fontSize": "32px",
                                    "lineHeight": "1.25",
                                    "fontFamily": "sans-serif",
                                    "letterSpacing": "0px",
                                    "wordSpacing": "0px",
                                    "fill": "#000000",
                                    "fillOpacity": "1",
                                    "stroke": "none"
                                }}>
                                    <path id="path3200" style={{
                                        "fontStyle": "normal",
                                        "fontVariant": "normal",
                                        "fontWeight": "bold",
                                        "fontStretch": "normal",
                                        "fontSize": "21.33333397px",
                                        "fontFamily": "Calibri",
                                        "InkscapeFontSpecification": "'Calibri Bold'",
                                        "fill": "#ffffff"
                                    }}
                                          d="m 318.00601,124.98941 q 0,0.53125 -0.11458,0.8125 -0.10417,0.27083 -0.29167,0.27083 h -1.19791 v 2.4375 q 0,0.10417 -0.0625,0.1875 -0.0625,0.0729 -0.21875,0.125 -0.15625,0.0521 -0.40625,0.0729 -0.25,0.0312 -0.64584,0.0312 -0.375,0 -0.63541,-0.0312 -0.25,-0.0208 -0.40625,-0.0729 -0.14584,-0.0521 -0.20834,-0.125 -0.0521,-0.0833 -0.0521,-0.1875 v -2.4375 h -5.15625 q -0.14583,0 -0.26042,-0.0312 -0.11458,-0.0417 -0.19791,-0.16666 -0.0729,-0.13542 -0.11459,-0.375 -0.0312,-0.25 -0.0312,-0.65625 0,-0.33334 0.0104,-0.57292 0.0208,-0.25 0.0521,-0.44792 0.0417,-0.19791 0.10417,-0.375 0.0729,-0.17708 0.17708,-0.375 l 4.1875,-7.38541 q 0.0521,-0.0937 0.17709,-0.15625 0.125,-0.0729 0.34375,-0.11459 0.22916,-0.0521 0.57291,-0.0729 0.34375,-0.0208 0.83334,-0.0208 0.53125,0 0.90625,0.0312 0.375,0.0208 0.59375,0.0833 0.22916,0.0521 0.33333,0.13541 0.10417,0.0833 0.10417,0.19792 v 8.11458 h 1.19791 q 0.16667,0 0.28125,0.26042 0.125,0.25 0.125,0.84375 z m -4.23958,-7.30208 h -0.0208 l -3.55209,6.19791 h 3.57292 z"/>
                                    <path id="path3202" style={{
                                        "fontStyle": "normal",
                                        "fontVariant": "normal",
                                        "fontWeight": "bold",
                                        "fontStretch": "normal",
                                        "fontSize": "21.33333397px",
                                        "fontFamily": "Calibri",
                                        "InkscapeFontSpecification": "'Calibri Bold'",
                                        "fill": "#ffffff"
                                    }}
                                          d="m 328.69351,122.07274 q 0,1.61459 -0.26041,2.91667 -0.26042,1.30208 -0.85417,2.21875 -0.58333,0.91667 -1.53125,1.40625 -0.9375,0.48958 -2.30208,0.48958 -1.38542,0 -2.29167,-0.46875 -0.90625,-0.47916 -1.4375,-1.36458 -0.53125,-0.89583 -0.75,-2.17708 -0.20833,-1.29167 -0.20833,-2.91667 0,-1.60417 0.26041,-2.90625 0.27084,-1.3125 0.85417,-2.22917 0.59375,-0.91666 1.53125,-1.40625 0.94792,-0.48958 2.30208,-0.48958 1.38542,0 2.29167,0.47917 0.91667,0.46875 1.44792,1.36458 0.53125,0.88542 0.73958,2.17708 0.20833,1.28125 0.20833,2.90625 z m -2.76041,0.13542 q 0,-0.95833 -0.0521,-1.6875 -0.0521,-0.73958 -0.16666,-1.28125 -0.10417,-0.54167 -0.27084,-0.91667 -0.15625,-0.375 -0.38541,-0.59375 -0.22917,-0.22916 -0.52084,-0.32291 -0.29166,-0.0937 -0.64583,-0.0937 -0.61458,0 -1.02083,0.30208 -0.39584,0.29167 -0.63542,0.88542 -0.22917,0.59375 -0.32292,1.47916 -0.0937,0.88542 -0.0937,2.0625 0,1.4375 0.11459,2.38542 0.11458,0.9375 0.35416,1.5 0.25,0.55208 0.63542,0.78125 0.38542,0.21875 0.92708,0.21875 0.40625,0 0.71875,-0.125 0.3125,-0.13542 0.54167,-0.39583 0.23958,-0.26042 0.39583,-0.65625 0.15625,-0.39584 0.25,-0.91667 0.10417,-0.52083 0.13542,-1.17708 0.0417,-0.65625 0.0417,-1.44792 z"/>
                                </g>
                                <g id="text2857-6" style={{
                                    "fontStyle": "normal",
                                    "fontWeight": "normal",
                                    "fontSize": "32px",
                                    "lineHeight": "1.25",
                                    "fontFamily": "sans-serif",
                                    "letterSpacing": "0px",
                                    "wordSpacing": "0px",
                                    "fill": "#000000",
                                    "fillOpacity": "1",
                                    "stroke": "none"
                                }}>
                                    <path id="path3129" style={{
                                        "fontStyle": "normal",
                                        "fontVariant": "normal",
                                        "fontWeight": "bold",
                                        "fontStretch": "normal",
                                        "fontSize": "21.33333397px",
                                        "fontFamily": "Calibri",
                                        "InkscapeFontSpecification": "'Calibri Bold'",
                                        "fill": "#ffffff"
                                    }}
                                          d="m 170.27209,284.46284 q 0,0.60417 -0.11458,0.84375 -0.11459,0.23958 -0.36459,0.23958 h -4.33333 q -0.26042,0 -0.375,-0.23958 -0.11458,-0.25 -0.11458,-0.84375 0,-0.58333 0.11458,-0.82292 0.11458,-0.23958 0.375,-0.23958 h 4.33333 q 0.125,0 0.20834,0.0521 0.0937,0.0521 0.15625,0.17709 0.0625,0.125 0.0833,0.33333 0.0312,0.20833 0.0312,0.5 z"/>
                                    <path id="path3131" style={{
                                        "fontStyle": "normal",
                                        "fontVariant": "normal",
                                        "fontWeight": "bold",
                                        "fontStretch": "normal",
                                        "fontSize": "21.33333397px",
                                        "fontFamily": "Calibri",
                                        "InkscapeFontSpecification": "'Calibri Bold'",
                                        "fill": "#ffffff"
                                    }}
                                          d="m 180.73042,288.66076 q 0,0.29166 -0.0312,0.5 -0.0312,0.19791 -0.0937,0.32291 -0.0521,0.11459 -0.125,0.16667 -0.0729,0.0521 -0.16666,0.0521 h -7.4375 q -0.0833,0 -0.15625,-0.0521 -0.0729,-0.0521 -0.13542,-0.16667 -0.0521,-0.125 -0.0833,-0.32291 -0.0312,-0.20834 -0.0312,-0.5 0,-0.30209 0.0208,-0.5 0.0312,-0.20834 0.0833,-0.33334 0.0625,-0.125 0.13542,-0.17708 0.0729,-0.0625 0.16667,-0.0625 h 2.51041 v -8.77083 l -2.16666,1.19791 q -0.23959,0.11459 -0.39584,0.14584 -0.14583,0.0208 -0.23958,-0.0625 -0.0833,-0.0937 -0.11458,-0.3125 -0.0312,-0.21875 -0.0312,-0.61459 0,-0.25 0.0104,-0.40625 0.0104,-0.16666 0.0521,-0.28125 0.0417,-0.11458 0.11458,-0.1875 0.0729,-0.0729 0.19792,-0.15625 l 2.89583,-1.875 q 0.0521,-0.0417 0.125,-0.0625 0.0833,-0.0312 0.20833,-0.0417 0.125,-0.0208 0.32292,-0.0208 0.20833,-0.0104 0.53125,-0.0104 0.39583,0 0.63542,0.0208 0.25,0.0104 0.375,0.0521 0.125,0.0312 0.16666,0.0937 0.0417,0.0625 0.0417,0.15625 v 11.13542 h 2.19792 q 0.0937,0 0.16666,0.0625 0.0833,0.0521 0.13542,0.17708 0.0625,0.125 0.0833,0.33334 0.0312,0.19791 0.0312,0.5 z"/>
                                    <path id="path3133" style={{
                                        "fontStyle": "normal",
                                        "fontVariant": "normal",
                                        "fontWeight": "bold",
                                        "fontStretch": "normal",
                                        "fontSize": "21.33333397px",
                                        "fontFamily": "Calibri",
                                        "InkscapeFontSpecification": "'Calibri Bold'",
                                        "fill": "#ffffff"
                                    }}
                                          d="m 191.95959,282.91076 q 0,1.61458 -0.26042,2.91666 -0.26041,1.30209 -0.85416,2.21875 -0.58334,0.91667 -1.53125,1.40625 -0.9375,0.48959 -2.30209,0.48959 -1.38541,0 -2.29166,-0.46875 -0.90625,-0.47917 -1.4375,-1.36459 -0.53125,-0.89583 -0.75,-2.17708 -0.20834,-1.29167 -0.20834,-2.91667 0,-1.60416 0.26042,-2.90625 0.27083,-1.3125 0.85417,-2.22916 0.59375,-0.91667 1.53125,-1.40625 0.94791,-0.48959 2.30208,-0.48959 1.38542,0 2.29167,0.47917 0.91666,0.46875 1.44791,1.36458 0.53125,0.88542 0.73959,2.17709 0.20833,1.28125 0.20833,2.90625 z m -2.76042,0.13541 q 0,-0.95833 -0.0521,-1.6875 -0.0521,-0.73958 -0.16667,-1.28125 -0.10416,-0.54166 -0.27083,-0.91666 -0.15625,-0.375 -0.38542,-0.59375 -0.22916,-0.22917 -0.52083,-0.32292 -0.29167,-0.0937 -0.64583,-0.0937 -0.61459,0 -1.02084,0.30208 -0.39583,0.29167 -0.63541,0.88542 -0.22917,0.59375 -0.32292,1.47917 -0.0937,0.88541 -0.0937,2.0625 0,1.4375 0.11458,2.38541 0.11459,0.9375 0.35417,1.5 0.25,0.55209 0.63542,0.78125 0.38541,0.21875 0.92708,0.21875 0.40625,0 0.71875,-0.125 0.3125,-0.13541 0.54167,-0.39583 0.23958,-0.26042 0.39583,-0.65625 0.15625,-0.39583 0.25,-0.91667 0.10417,-0.52083 0.13542,-1.17708 0.0417,-0.65625 0.0417,-1.44792 z"/>
                                </g>
                                <g id="text2857-2-4" style={{
                                    "fontStyle": "normal",
                                    "fontWeight": "normal",
                                    "fontSize": "32px",
                                    "lineHeight": "1.25",
                                    "fontFamily": "sans-serif",
                                    "letterSpacing": "0px",
                                    "wordSpacing": "0px",
                                    "fill": "#000000",
                                    "fillOpacity": "1",
                                    "stroke": "none"
                                }}>
                                    <path id="path3178" style={{
                                        "fontStyle": "normal",
                                        "fontVariant": "normal",
                                        "fontWeight": "bold",
                                        "fontStretch": "normal",
                                        "fontSize": "21.33333397px",
                                        "fontFamily": "Calibri",
                                        "InkscapeFontSpecification": "'Calibri Bold'",
                                        "fill": "#ffffff"
                                    }}
                                          d="m 313.07209,284.28767 q 0,0.60417 -0.11458,0.84375 -0.11458,0.23958 -0.36458,0.23958 h -4.33334 q -0.26041,0 -0.375,-0.23958 -0.11458,-0.25 -0.11458,-0.84375 0,-0.58333 0.11458,-0.82292 0.11459,-0.23958 0.375,-0.23958 h 4.33334 q 0.125,0 0.20833,0.0521 0.0937,0.0521 0.15625,0.17709 0.0625,0.125 0.0833,0.33333 0.0312,0.20833 0.0312,0.5 z"/>
                                    <path id="path3180" style={{
                                        "fontStyle": "normal",
                                        "fontVariant": "normal",
                                        "fontWeight": "bold",
                                        "fontStretch": "normal",
                                        "fontSize": "21.33333397px",
                                        "fontFamily": "Calibri",
                                        "InkscapeFontSpecification": "'Calibri Bold'",
                                        "fill": "#ffffff"
                                    }}
                                          d="m 323.53043,288.48559 q 0,0.29166 -0.0312,0.5 -0.0312,0.19791 -0.0937,0.32291 -0.0521,0.11459 -0.125,0.16667 -0.0729,0.0521 -0.16667,0.0521 h -7.4375 q -0.0833,0 -0.15625,-0.0521 -0.0729,-0.0521 -0.13542,-0.16667 -0.0521,-0.125 -0.0833,-0.32291 -0.0312,-0.20834 -0.0312,-0.5 0,-0.30209 0.0208,-0.5 0.0312,-0.20834 0.0833,-0.33334 0.0625,-0.125 0.13541,-0.17708 0.0729,-0.0625 0.16667,-0.0625 h 2.51042 v -8.77083 l -2.16667,1.19791 q -0.23958,0.11459 -0.39583,0.14584 -0.14584,0.0208 -0.23959,-0.0625 -0.0833,-0.0937 -0.11458,-0.3125 -0.0312,-0.21875 -0.0312,-0.61459 0,-0.25 0.0104,-0.40625 0.0104,-0.16666 0.0521,-0.28125 0.0417,-0.11458 0.11458,-0.1875 0.0729,-0.0729 0.19792,-0.15625 l 2.89583,-1.875 q 0.0521,-0.0417 0.125,-0.0625 0.0833,-0.0312 0.20834,-0.0417 0.125,-0.0208 0.32291,-0.0208 0.20834,-0.0104 0.53125,-0.0104 0.39584,0 0.63542,0.0208 0.25,0.0104 0.375,0.0521 0.125,0.0312 0.16667,0.0937 0.0417,0.0625 0.0417,0.15625 v 11.13542 h 2.19792 q 0.0937,0 0.16667,0.0625 0.0833,0.0521 0.13541,0.17708 0.0625,0.125 0.0833,0.33334 0.0312,0.19791 0.0312,0.5 z"/>
                                    <path id="path3182" style={{
                                        "fontStyle": "normal",
                                        "fontVariant": "normal",
                                        "fontWeight": "bold",
                                        "fontStretch": "normal",
                                        "fontSize": "21.33333397px",
                                        "fontFamily": "Calibri",
                                        "InkscapeFontSpecification": "'Calibri Bold'",
                                        "fill": "#ffffff"
                                    }}
                                          d="m 334.75959,282.73559 q 0,1.61458 -0.26041,2.91666 -0.26042,1.30209 -0.85417,2.21875 -0.58333,0.91667 -1.53125,1.40625 -0.9375,0.48959 -2.30208,0.48959 -1.38542,0 -2.29167,-0.46875 -0.90625,-0.47917 -1.4375,-1.36459 -0.53125,-0.89583 -0.75,-2.17708 -0.20833,-1.29167 -0.20833,-2.91667 0,-1.60416 0.26041,-2.90625 0.27084,-1.3125 0.85417,-2.22916 0.59375,-0.91667 1.53125,-1.40625 0.94792,-0.48959 2.30208,-0.48959 1.38542,0 2.29167,0.47917 0.91667,0.46875 1.44792,1.36458 0.53125,0.88542 0.73958,2.17709 0.20833,1.28125 0.20833,2.90625 z m -2.76041,0.13541 q 0,-0.95833 -0.0521,-1.6875 -0.0521,-0.73958 -0.16666,-1.28125 -0.10417,-0.54166 -0.27084,-0.91666 -0.15625,-0.375 -0.38541,-0.59375 -0.22917,-0.22917 -0.52084,-0.32292 -0.29166,-0.0937 -0.64583,-0.0937 -0.61458,0 -1.02083,0.30208 -0.39584,0.29167 -0.63542,0.88542 -0.22917,0.59375 -0.32292,1.47917 -0.0937,0.88541 -0.0937,2.0625 0,1.4375 0.11459,2.38541 0.11458,0.9375 0.35416,1.5 0.25,0.55209 0.63542,0.78125 0.38542,0.21875 0.92708,0.21875 0.40625,0 0.71875,-0.125 0.3125,-0.13541 0.54167,-0.39583 0.23958,-0.26042 0.39583,-0.65625 0.15625,-0.39583 0.25,-0.91667 0.10417,-0.52083 0.13542,-1.17708 0.0417,-0.65625 0.0417,-1.44792 z"/>
                                </g>
                                <g id="text2857-24-9" style={{
                                    "fontStyle": "normal",
                                    "fontWeight": "normal",
                                    "fontSize": "32px",
                                    "lineHeight": "1.25",
                                    "fontFamily": "sans-serif",
                                    "letterSpacing": "0px",
                                    "wordSpacing": "0px",
                                    "fill": "#000000",
                                    "fillOpacity": "1",
                                    "stroke": "none"
                                }}>
                                    <path id="path3136" style={{
                                        "fontStyle": "normal",
                                        "fontVariant": "normal",
                                        "fontWeight": "bold",
                                        "fontStretch": "normal",
                                        "fontSize": "21.33333397px",
                                        "fontFamily": "Calibri",
                                        "InkscapeFontSpecification": "'Calibri Bold'",
                                        "fill": "#ffffff"
                                    }}
                                          d="m 170.19508,316.25184 q 0,0.60417 -0.11458,0.84375 -0.11459,0.23958 -0.36459,0.23958 h -4.33333 q -0.26042,0 -0.375,-0.23958 -0.11458,-0.25 -0.11458,-0.84375 0,-0.58333 0.11458,-0.82292 0.11458,-0.23958 0.375,-0.23958 h 4.33333 q 0.125,0 0.20834,0.0521 0.0937,0.0521 0.15625,0.17709 0.0625,0.125 0.0833,0.33333 0.0312,0.20833 0.0312,0.5 z"/>
                                    <path id="path3138" style={{
                                        "fontStyle": "normal",
                                        "fontVariant": "normal",
                                        "fontWeight": "bold",
                                        "fontStretch": "normal",
                                        "fontSize": "21.33333397px",
                                        "fontFamily": "Calibri",
                                        "InkscapeFontSpecification": "'Calibri Bold'",
                                        "fill": "#ffffff"
                                    }}
                                          d="m 180.77841,320.37684 q 0,0.30208 -0.0312,0.52083 -0.0208,0.20834 -0.0729,0.34375 -0.0521,0.13542 -0.13542,0.19792 -0.0833,0.0521 -0.1875,0.0521 h -7.75 q -0.22917,0 -0.39583,-0.0417 -0.16667,-0.0417 -0.27084,-0.15625 -0.10416,-0.125 -0.15625,-0.35417 -0.0417,-0.22917 -0.0417,-0.59375 0,-0.34375 0.0312,-0.58333 0.0312,-0.25 0.11458,-0.4375 0.0833,-0.19792 0.20833,-0.375 0.13542,-0.1875 0.34375,-0.40625 l 2.33334,-2.5 q 0.69791,-0.72917 1.125,-1.32292 0.42708,-0.60417 0.66666,-1.09375 0.23959,-0.5 0.32292,-0.91667 0.0937,-0.41666 0.0937,-0.79166 0,-0.34375 -0.11458,-0.64584 -0.10417,-0.3125 -0.32292,-0.54166 -0.20833,-0.22917 -0.53125,-0.35417 -0.32292,-0.13542 -0.76042,-0.13542 -0.61458,0 -1.09375,0.15625 -0.46875,0.15625 -0.83333,0.35417 -0.35417,0.1875 -0.59375,0.35417 -0.23958,0.15625 -0.375,0.15625 -0.0937,0 -0.16667,-0.0625 -0.0625,-0.0625 -0.10416,-0.20834 -0.0417,-0.14583 -0.0729,-0.38541 -0.0208,-0.25 -0.0208,-0.60417 0,-0.23958 0.0104,-0.39583 0.0208,-0.16667 0.0521,-0.28125 0.0312,-0.125 0.0833,-0.20834 0.0521,-0.0937 0.17708,-0.21875 0.13542,-0.125 0.47917,-0.3125 0.35417,-0.19791 0.86458,-0.375 0.51042,-0.1875 1.125,-0.3125 0.61459,-0.125 1.28125,-0.125 1.05209,0 1.83334,0.27084 0.79166,0.26041 1.3125,0.73958 0.52083,0.46875 0.77083,1.125 0.26042,0.64583 0.26042,1.39583 0,0.65625 -0.125,1.29167 -0.125,0.63542 -0.52084,1.375 -0.39583,0.72917 -1.11458,1.625 -0.71875,0.88542 -1.90625,2.0625 l -1.57292,1.61458 h 5.3125 q 0.10417,0 0.1875,0.0625 0.0937,0.0625 0.15625,0.19792 0.0625,0.125 0.0937,0.34375 0.0312,0.20833 0.0312,0.5 z"/>
                                    <path id="path3140" style={{
                                        "fontStyle": "normal",
                                        "fontVariant": "normal",
                                        "fontWeight": "bold",
                                        "fontStretch": "normal",
                                        "fontSize": "21.33333397px",
                                        "fontFamily": "Calibri",
                                        "InkscapeFontSpecification": "'Calibri Bold'",
                                        "fill": "#ffffff"
                                    }}
                                          d="m 191.88258,314.69976 q 0,1.61458 -0.26042,2.91666 -0.26041,1.30209 -0.85416,2.21875 -0.58334,0.91667 -1.53125,1.40625 -0.9375,0.48959 -2.30209,0.48959 -1.38541,0 -2.29166,-0.46875 -0.90625,-0.47917 -1.4375,-1.36459 -0.53125,-0.89583 -0.75,-2.17708 -0.20834,-1.29167 -0.20834,-2.91667 0,-1.60416 0.26042,-2.90625 0.27083,-1.3125 0.85417,-2.22916 0.59375,-0.91667 1.53125,-1.40625 0.94791,-0.48959 2.30208,-0.48959 1.38542,0 2.29167,0.47917 0.91666,0.46875 1.44791,1.36458 0.53125,0.88542 0.73959,2.17709 0.20833,1.28125 0.20833,2.90625 z m -2.76042,0.13541 q 0,-0.95833 -0.0521,-1.6875 -0.0521,-0.73958 -0.16667,-1.28125 -0.10416,-0.54166 -0.27083,-0.91666 -0.15625,-0.375 -0.38542,-0.59375 -0.22916,-0.22917 -0.52083,-0.32292 -0.29167,-0.0937 -0.64583,-0.0937 -0.61459,0 -1.02084,0.30208 -0.39583,0.29167 -0.63541,0.88542 -0.22917,0.59375 -0.32292,1.47917 -0.0937,0.88541 -0.0937,2.0625 0,1.4375 0.11458,2.38541 0.11459,0.9375 0.35417,1.5 0.25,0.55209 0.63542,0.78125 0.38541,0.21875 0.92708,0.21875 0.40625,0 0.71875,-0.125 0.3125,-0.13541 0.54167,-0.39583 0.23958,-0.26042 0.39583,-0.65625 0.15625,-0.39583 0.25,-0.91667 0.10417,-0.52083 0.13542,-1.17708 0.0417,-0.65625 0.0417,-1.44792 z"/>
                                </g>
                                <g id="text2857-24-2-9" style={{
                                    "fontStyle": "normal",
                                    "fontWeight": "normal",
                                    "fontSize": "32px",
                                    "lineHeight": "1.25",
                                    "fontFamily": "sans-serif",
                                    "letterSpacing": "0px",
                                    "wordSpacing": "0px",
                                    "fill": "#000000",
                                    "fillOpacity": "1",
                                    "stroke": "none"
                                }}>
                                    <path id="path3171" style={{
                                        "fontStyle": "normal",
                                        "fontVariant": "normal",
                                        "fontWeight": "bold",
                                        "fontStretch": "normal",
                                        "fontSize": "21.33333397px",
                                        "fontFamily": "Calibri",
                                        "InkscapeFontSpecification": "'Calibri Bold'",
                                        "fill": "#ffffff"
                                    }}
                                          d="m 313.07872,316.04551 q 0,0.60417 -0.11459,0.84375 -0.11458,0.23959 -0.36458,0.23959 h -4.33333 q -0.26042,0 -0.375,-0.23959 -0.11459,-0.25 -0.11459,-0.84375 0,-0.58333 0.11459,-0.82291 0.11458,-0.23959 0.375,-0.23959 h 4.33333 q 0.125,0 0.20833,0.0521 0.0937,0.0521 0.15625,0.17708 0.0625,0.125 0.0833,0.33333 0.0312,0.20834 0.0312,0.5 z"/>
                                    <path id="path3173" style={{
                                        "fontStyle": "normal",
                                        "fontVariant": "normal",
                                        "fontWeight": "bold",
                                        "fontStretch": "normal",
                                        "fontSize": "21.33333397px",
                                        "fontFamily": "Calibri",
                                        "InkscapeFontSpecification": "'Calibri Bold'",
                                        "fill": "#ffffff"
                                    }}
                                          d="m 323.66205,320.17051 q 0,0.30209 -0.0312,0.52084 -0.0208,0.20833 -0.0729,0.34375 -0.0521,0.13541 -0.13541,0.19791 -0.0833,0.0521 -0.1875,0.0521 h -7.75 q -0.22917,0 -0.39584,-0.0417 -0.16666,-0.0417 -0.27083,-0.15625 -0.10417,-0.125 -0.15625,-0.35417 -0.0417,-0.22916 -0.0417,-0.59375 0,-0.34375 0.0312,-0.58333 0.0312,-0.25 0.11459,-0.4375 0.0833,-0.19792 0.20833,-0.375 0.13542,-0.1875 0.34375,-0.40625 l 2.33333,-2.5 q 0.69792,-0.72917 1.125,-1.32292 0.42709,-0.60417 0.66667,-1.09375 0.23958,-0.5 0.32292,-0.91667 0.0937,-0.41666 0.0937,-0.79166 0,-0.34375 -0.11459,-0.64584 -0.10416,-0.3125 -0.32291,-0.54166 -0.20834,-0.22917 -0.53125,-0.35417 -0.32292,-0.13542 -0.76042,-0.13542 -0.61458,0 -1.09375,0.15625 -0.46875,0.15625 -0.83333,0.35417 -0.35417,0.1875 -0.59375,0.35417 -0.23959,0.15625 -0.375,0.15625 -0.0937,0 -0.16667,-0.0625 -0.0625,-0.0625 -0.10417,-0.20834 -0.0417,-0.14583 -0.0729,-0.38541 -0.0208,-0.25 -0.0208,-0.60417 0,-0.23958 0.0104,-0.39583 0.0208,-0.16667 0.0521,-0.28125 0.0312,-0.125 0.0833,-0.20834 0.0521,-0.0937 0.17708,-0.21875 0.13542,-0.125 0.47917,-0.3125 0.35416,-0.19791 0.86458,-0.375 0.51042,-0.1875 1.125,-0.3125 0.61458,-0.125 1.28125,-0.125 1.05208,0 1.83333,0.27084 0.79167,0.26041 1.3125,0.73958 0.52084,0.46875 0.77084,1.125 0.26041,0.64583 0.26041,1.39583 0,0.65625 -0.125,1.29167 -0.125,0.63542 -0.52083,1.375 -0.39583,0.72917 -1.11458,1.625 -0.71875,0.88542 -1.90625,2.0625 l -1.57292,1.61459 h 5.3125 q 0.10417,0 0.1875,0.0625 0.0937,0.0625 0.15625,0.19791 0.0625,0.125 0.0937,0.34375 0.0312,0.20834 0.0312,0.5 z"/>
                                    <path id="path3175" style={{
                                        "fontStyle": "normal",
                                        "fontVariant": "normal",
                                        "fontWeight": "bold",
                                        "fontStretch": "normal",
                                        "fontSize": "21.33333397px",
                                        "fontFamily": "Calibri",
                                        "InkscapeFontSpecification": "'Calibri Bold'",
                                        "fill": "#ffffff"
                                    }}
                                          d="m 334.76622,314.49343 q 0,1.61458 -0.26042,2.91667 -0.26042,1.30208 -0.85417,2.21875 -0.58333,0.91666 -1.53125,1.40625 -0.9375,0.48958 -2.30208,0.48958 -1.38542,0 -2.29167,-0.46875 -0.90625,-0.47917 -1.4375,-1.36458 -0.53125,-0.89584 -0.75,-2.17709 -0.20833,-1.29166 -0.20833,-2.91666 0,-1.60417 0.26042,-2.90626 0.27083,-1.3125 0.85416,-2.22916 0.59375,-0.91667 1.53125,-1.40625 0.94792,-0.48959 2.30209,-0.48959 1.38541,0 2.29166,0.47917 0.91667,0.46875 1.44792,1.36458 0.53125,0.88542 0.73958,2.17709 0.20834,1.28125 0.20834,2.90625 z m -2.76042,0.13542 q 0,-0.95834 -0.0521,-1.68751 -0.0521,-0.73958 -0.16667,-1.28125 -0.10417,-0.54166 -0.27083,-0.91666 -0.15625,-0.375 -0.38542,-0.59375 -0.22917,-0.22917 -0.52083,-0.32292 -0.29167,-0.0937 -0.64584,-0.0937 -0.61458,0 -1.02083,0.30208 -0.39583,0.29167 -0.63542,0.88542 -0.22916,0.59375 -0.32291,1.47917 -0.0937,0.88541 -0.0937,2.0625 0,1.4375 0.11458,2.38542 0.11458,0.9375 0.35417,1.5 0.25,0.55208 0.63541,0.78125 0.38542,0.21875 0.92709,0.21875 0.40625,0 0.71875,-0.125 0.3125,-0.13542 0.54166,-0.39584 0.23959,-0.26041 0.39584,-0.65625 0.15625,-0.39583 0.25,-0.91666 0.10416,-0.52084 0.13541,-1.17709 0.0417,-0.65625 0.0417,-1.44791 z"/>
                                </g>
                                <g id="text2857-24-5-0" style={{
                                    "fontStyle": "normal",
                                    "fontWeight": "normal",
                                    "fontSize": "32px",
                                    "lineHeight": "1.25",
                                    "fontFamily": "sans-serif",
                                    "letterSpacing": "0px",
                                    "wordSpacing": "0px",
                                    "fill": "#000000",
                                    "fillOpacity": "1",
                                    "stroke": "none"
                                }}>
                                    <path id="path3143" style={{
                                        "fontStyle": "normal",
                                        "fontVariant": "normal",
                                        "fontWeight": "bold",
                                        "fontStretch": "normal",
                                        "fontSize": "21.33333397px",
                                        "fontFamily": "Calibri",
                                        "InkscapeFontSpecification": "'Calibri Bold'",
                                        "fill": "#ffffff"
                                    }}
                                          d="m 170.14709,347.71183 q 0,0.60417 -0.11458,0.84375 -0.11459,0.23959 -0.36459,0.23959 h -4.33333 q -0.26042,0 -0.375,-0.23959 -0.11458,-0.25 -0.11458,-0.84375 0,-0.58333 0.11458,-0.82291 0.11458,-0.23959 0.375,-0.23959 h 4.33333 q 0.125,0 0.20834,0.0521 0.0937,0.0521 0.15625,0.17708 0.0625,0.125 0.0833,0.33333 0.0312,0.20834 0.0312,0.5 z"/>
                                    <path id="path3145" style={{
                                        "fontStyle": "normal",
                                        "fontVariant": "normal",
                                        "fontWeight": "bold",
                                        "fontStretch": "normal",
                                        "fontSize": "21.33333397px",
                                        "fontFamily": "Calibri",
                                        "InkscapeFontSpecification": "'Calibri Bold'",
                                        "fill": "#ffffff"
                                    }}
                                          d="m 180.66792,349.0035 q 0,1.01042 -0.38541,1.79167 -0.38542,0.78125 -1.07292,1.3125 -0.6875,0.53125 -1.64583,0.8125 -0.95834,0.27083 -2.09375,0.27083 -0.6875,0 -1.29167,-0.10417 -0.60417,-0.0937 -1.07292,-0.23958 -0.45833,-0.14583 -0.76041,-0.30208 -0.30209,-0.15625 -0.39584,-0.23959 -0.0937,-0.0833 -0.14583,-0.1875 -0.0417,-0.10416 -0.0833,-0.23958 -0.0312,-0.14583 -0.0521,-0.35417 -0.0104,-0.21875 -0.0104,-0.52083 0,-0.5 0.0833,-0.6875 0.0833,-0.19792 0.25,-0.19792 0.10417,0 0.35417,0.14584 0.26041,0.13541 0.65625,0.30208 0.39583,0.15625 0.92708,0.30208 0.53125,0.13542 1.20833,0.13542 0.57292,0 1.01042,-0.13542 0.4375,-0.13541 0.73958,-0.375 0.3125,-0.25 0.45834,-0.59375 0.15625,-0.35416 0.15625,-0.78125 0,-0.46875 -0.1875,-0.84375 -0.17709,-0.375 -0.54167,-0.63541 -0.35417,-0.27084 -0.90625,-0.41667 -0.54167,-0.14583 -1.28125,-0.14583 h -1.16667 q -0.13541,0 -0.22916,-0.0312 -0.0937,-0.0417 -0.15625,-0.15625 -0.0625,-0.11459 -0.0937,-0.3125 -0.0208,-0.20834 -0.0208,-0.53125 0,-0.30209 0.0208,-0.48959 0.0312,-0.19791 0.0833,-0.30208 0.0625,-0.10417 0.14583,-0.14583 0.0937,-0.0417 0.21875,-0.0417 h 1.17709 q 0.60416,0 1.07291,-0.13542 0.46875,-0.14583 0.78125,-0.40625 0.32292,-0.26041 0.48959,-0.625 0.16666,-0.375 0.16666,-0.82291 0,-0.34375 -0.11458,-0.64584 -0.11458,-0.3125 -0.34375,-0.53125 -0.21875,-0.22916 -0.57292,-0.35416 -0.35416,-0.13542 -0.83333,-0.13542 -0.54167,0 -1.02083,0.16667 -0.47917,0.15625 -0.86459,0.35416 -0.375,0.1875 -0.64583,0.35417 -0.26042,0.16667 -0.38542,0.16667 -0.0833,0 -0.14583,-0.0312 -0.0625,-0.0417 -0.10417,-0.14584 -0.0417,-0.10416 -0.0625,-0.30208 -0.0208,-0.19792 -0.0208,-0.51042 0,-0.26041 0.0104,-0.42708 0.0104,-0.17708 0.0417,-0.29167 0.0312,-0.11458 0.0729,-0.19791 0.0521,-0.0833 0.15625,-0.17709 0.10417,-0.10416 0.42708,-0.30208 0.32292,-0.19792 0.8125,-0.38542 0.48959,-0.1875 1.125,-0.3125 0.64584,-0.13541 1.39584,-0.13541 0.97916,0 1.72916,0.22916 0.76042,0.22917 1.27084,0.66667 0.52083,0.42708 0.78125,1.0625 0.27083,0.625 0.27083,1.41667 0,0.61458 -0.15625,1.14583 -0.15625,0.53125 -0.45833,0.94792 -0.30209,0.41666 -0.76042,0.70833 -0.44792,0.29167 -1.04167,0.4375 v 0.0312 q 0.70834,0.0833 1.27084,0.36458 0.5625,0.27084 0.94791,0.6875 0.39584,0.41667 0.60417,0.94792 0.20833,0.52083 0.20833,1.125 z"/>
                                    <path id="path3147" style={{
                                        "fontStyle": "normal",
                                        "fontVariant": "normal",
                                        "fontWeight": "bold",
                                        "fontStretch": "normal",
                                        "fontSize": "21.33333397px",
                                        "fontFamily": "Calibri",
                                        "InkscapeFontSpecification": "'Calibri Bold'",
                                        "fill": "#ffffff"
                                    }}
                                          d="m 191.83459,346.15975 q 0,1.61458 -0.26042,2.91667 -0.26041,1.30208 -0.85416,2.21875 -0.58334,0.91666 -1.53125,1.40625 -0.9375,0.48958 -2.30209,0.48958 -1.38541,0 -2.29166,-0.46875 -0.90625,-0.47917 -1.4375,-1.36458 -0.53125,-0.89584 -0.75,-2.17709 -0.20834,-1.29166 -0.20834,-2.91666 0,-1.60417 0.26042,-2.90625 0.27083,-1.3125 0.85417,-2.22917 0.59375,-0.91667 1.53125,-1.40625 0.94791,-0.48958 2.30208,-0.48958 1.38542,0 2.29167,0.47916 0.91666,0.46875 1.44791,1.36459 0.53125,0.88541 0.73959,2.17708 0.20833,1.28125 0.20833,2.90625 z m -2.76042,0.13542 q 0,-0.95834 -0.0521,-1.6875 -0.0521,-0.73959 -0.16667,-1.28125 -0.10416,-0.54167 -0.27083,-0.91667 -0.15625,-0.375 -0.38542,-0.59375 -0.22916,-0.22917 -0.52083,-0.32292 -0.29167,-0.0937 -0.64583,-0.0937 -0.61459,0 -1.02084,0.30209 -0.39583,0.29166 -0.63541,0.88541 -0.22917,0.59375 -0.32292,1.47917 -0.0937,0.88542 -0.0937,2.0625 0,1.4375 0.11458,2.38542 0.11459,0.9375 0.35417,1.5 0.25,0.55208 0.63542,0.78125 0.38541,0.21875 0.92708,0.21875 0.40625,0 0.71875,-0.125 0.3125,-0.13542 0.54167,-0.39584 0.23958,-0.26041 0.39583,-0.65625 0.15625,-0.39583 0.25,-0.91666 0.10417,-0.52084 0.13542,-1.17709 0.0417,-0.65625 0.0417,-1.44791 z"/>
                                </g>
                                <g id="text2857-24-5-17-7" style={{
                                    "fontStyle": "normal",
                                    "fontWeight": "normal",
                                    "fontSize": "32px",
                                    "lineHeight": "1.25",
                                    "fontFamily": "sans-serif",
                                    "letterSpacing": "0px",
                                    "wordSpacing": "0px",
                                    "fill": "#000000",
                                    "fillOpacity": "1",
                                    "stroke": "none"
                                }}>
                                    <path id="path3164" style={{
                                        "fontStyle": "normal",
                                        "fontVariant": "normal",
                                        "fontWeight": "bold",
                                        "fontStretch": "normal",
                                        "fontSize": "21.33333397px",
                                        "fontFamily": "Calibri",
                                        "InkscapeFontSpecification": "'Calibri Bold'",
                                        "fill": "#ffffff"
                                    }}
                                          d="m 313.10099,347.44367 q 0,0.60417 -0.11458,0.84375 -0.11458,0.23959 -0.36458,0.23959 h -4.33334 q -0.26041,0 -0.375,-0.23959 -0.11458,-0.25 -0.11458,-0.84375 0,-0.58333 0.11458,-0.82291 0.11459,-0.23959 0.375,-0.23959 h 4.33334 q 0.125,0 0.20833,0.0521 0.0937,0.0521 0.15625,0.17708 0.0625,0.125 0.0833,0.33333 0.0312,0.20834 0.0312,0.5 z"/>
                                    <path id="path3166" style={{
                                        "fontStyle": "normal",
                                        "fontVariant": "normal",
                                        "fontWeight": "bold",
                                        "fontStretch": "normal",
                                        "fontSize": "21.33333397px",
                                        "fontFamily": "Calibri",
                                        "InkscapeFontSpecification": "'Calibri Bold'",
                                        "fill": "#ffffff"
                                    }}
                                          d="m 323.62183,348.73534 q 0,1.01042 -0.38542,1.79167 -0.38542,0.78125 -1.07292,1.3125 -0.6875,0.53125 -1.64583,0.8125 -0.95833,0.27083 -2.09375,0.27083 -0.6875,0 -1.29167,-0.10417 -0.60416,-0.0937 -1.07291,-0.23958 -0.45834,-0.14583 -0.76042,-0.30208 -0.30208,-0.15625 -0.39583,-0.23959 -0.0937,-0.0833 -0.14584,-0.1875 -0.0417,-0.10416 -0.0833,-0.23958 -0.0312,-0.14583 -0.0521,-0.35417 -0.0104,-0.21875 -0.0104,-0.52083 0,-0.5 0.0833,-0.6875 0.0833,-0.19792 0.25,-0.19792 0.10417,0 0.35417,0.14584 0.26042,0.13541 0.65625,0.30208 0.39583,0.15625 0.92708,0.30208 0.53125,0.13542 1.20834,0.13542 0.57291,0 1.01041,-0.13542 0.4375,-0.13541 0.73959,-0.375 0.3125,-0.25 0.45833,-0.59375 0.15625,-0.35416 0.15625,-0.78125 0,-0.46875 -0.1875,-0.84375 -0.17708,-0.375 -0.54167,-0.63541 -0.35416,-0.27084 -0.90625,-0.41667 -0.54166,-0.14583 -1.28125,-0.14583 h -1.16666 q -0.13542,0 -0.22917,-0.0312 -0.0937,-0.0417 -0.15625,-0.15625 -0.0625,-0.11459 -0.0937,-0.3125 -0.0208,-0.20834 -0.0208,-0.53125 0,-0.30209 0.0208,-0.48959 0.0312,-0.19791 0.0833,-0.30208 0.0625,-0.10417 0.14584,-0.14583 0.0937,-0.0417 0.21875,-0.0417 h 1.17708 q 0.60417,0 1.07292,-0.13542 0.46875,-0.14583 0.78125,-0.40625 0.32291,-0.26041 0.48958,-0.625 0.16667,-0.375 0.16667,-0.82291 0,-0.34375 -0.11459,-0.64584 -0.11458,-0.3125 -0.34375,-0.53125 -0.21875,-0.22916 -0.57291,-0.35416 -0.35417,-0.13542 -0.83334,-0.13542 -0.54166,0 -1.02083,0.16667 -0.47917,0.15625 -0.86458,0.35416 -0.375,0.1875 -0.64584,0.35417 -0.26041,0.16667 -0.38541,0.16667 -0.0833,0 -0.14584,-0.0312 -0.0625,-0.0417 -0.10416,-0.14584 -0.0417,-0.10416 -0.0625,-0.30208 -0.0208,-0.19792 -0.0208,-0.51042 0,-0.26041 0.0104,-0.42708 0.0104,-0.17708 0.0417,-0.29167 0.0312,-0.11458 0.0729,-0.19791 0.0521,-0.0833 0.15625,-0.17709 0.10417,-0.10416 0.42709,-0.30208 0.32291,-0.19792 0.8125,-0.38542 0.48958,-0.1875 1.125,-0.3125 0.64583,-0.13541 1.39583,-0.13541 0.97917,0 1.72917,0.22916 0.76041,0.22917 1.27083,0.66667 0.52083,0.42708 0.78125,1.0625 0.27083,0.625 0.27083,1.41667 0,0.61458 -0.15625,1.14583 -0.15625,0.53125 -0.45833,0.94792 -0.30208,0.41666 -0.76042,0.70833 -0.44791,0.29167 -1.04166,0.4375 v 0.0312 q 0.70833,0.0833 1.27083,0.36458 0.5625,0.27084 0.94792,0.6875 0.39583,0.41667 0.60416,0.94792 0.20834,0.52083 0.20834,1.125 z"/>
                                    <path id="path3168" style={{
                                        "fontStyle": "normal",
                                        "fontVariant": "normal",
                                        "fontWeight": "bold",
                                        "fontStretch": "normal",
                                        "fontSize": "21.33333397px",
                                        "fontFamily": "Calibri",
                                        "InkscapeFontSpecification": "'Calibri Bold'",
                                        "fill": "#ffffff"
                                    }}
                                          d="m 334.78849,345.89159 q 0,1.61458 -0.26041,2.91667 -0.26042,1.30208 -0.85417,2.21875 -0.58333,0.91666 -1.53125,1.40625 -0.9375,0.48958 -2.30208,0.48958 -1.38542,0 -2.29167,-0.46875 -0.90625,-0.47917 -1.4375,-1.36458 -0.53125,-0.89584 -0.75,-2.17709 -0.20833,-1.29166 -0.20833,-2.91666 0,-1.60417 0.26041,-2.90625 0.27084,-1.3125 0.85417,-2.22917 0.59375,-0.91667 1.53125,-1.40625 0.94792,-0.48958 2.30208,-0.48958 1.38542,0 2.29167,0.47916 0.91667,0.46875 1.44792,1.36459 0.53125,0.88541 0.73958,2.17708 0.20833,1.28125 0.20833,2.90625 z m -2.76041,0.13542 q 0,-0.95834 -0.0521,-1.6875 -0.0521,-0.73959 -0.16666,-1.28125 -0.10417,-0.54167 -0.27084,-0.91667 -0.15625,-0.375 -0.38541,-0.59375 -0.22917,-0.22917 -0.52084,-0.32292 -0.29166,-0.0937 -0.64583,-0.0937 -0.61458,0 -1.02083,0.30209 -0.39584,0.29166 -0.63542,0.88541 -0.22917,0.59375 -0.32292,1.47917 -0.0937,0.88542 -0.0937,2.0625 0,1.4375 0.11459,2.38542 0.11458,0.9375 0.35416,1.5 0.25,0.55208 0.63542,0.78125 0.38542,0.21875 0.92708,0.21875 0.40625,0 0.71875,-0.125 0.3125,-0.13542 0.54167,-0.39584 0.23958,-0.26041 0.39583,-0.65625 0.15625,-0.39583 0.25,-0.91666 0.10417,-0.52084 0.13542,-1.17709 0.0417,-0.65625 0.0417,-1.44791 z"/>
                                </g>
                                <g id="text2857-24-5-1-2" style={{
                                    "fontStyle": "normal",
                                    "fontWeight": "normal",
                                    "fontSize": "32px",
                                    "lineHeight": "1.25",
                                    "fontFamily": "sans-serif",
                                    "letterSpacing": "0px",
                                    "wordSpacing": "0px",
                                    "fill": "#000000",
                                    "fillOpacity": "1",
                                    "stroke": "none"
                                }}>
                                    <path id="path3150" style={{
                                        "fontStyle": "normal",
                                        "fontVariant": "normal",
                                        "fontWeight": "bold",
                                        "fontStretch": "normal",
                                        "fontSize": "21.33333397px",
                                        "fontFamily": "Calibri",
                                        "InkscapeFontSpecification": "'Calibri Bold'",
                                        "fill": "#ffffff"
                                    }}
                                          d="m 170.24409,379.51182 q 0,0.60417 -0.11458,0.84375 -0.11459,0.23958 -0.36459,0.23958 h -4.33333 q -0.26042,0 -0.375,-0.23958 -0.11458,-0.25 -0.11458,-0.84375 0,-0.58333 0.11458,-0.82292 0.11458,-0.23958 0.375,-0.23958 h 4.33333 q 0.125,0 0.20834,0.0521 0.0937,0.0521 0.15625,0.17709 0.0625,0.125 0.0833,0.33333 0.0312,0.20833 0.0312,0.5 z"/>
                                    <path id="path3152" style={{
                                        "fontStyle": "normal",
                                        "fontVariant": "normal",
                                        "fontWeight": "bold",
                                        "fontStretch": "normal",
                                        "fontSize": "21.33333397px",
                                        "fontFamily": "Calibri",
                                        "InkscapeFontSpecification": "'Calibri Bold'",
                                        "fill": "#ffffff"
                                    }}
                                          d="m 181.24409,380.8764 q 0,0.53125 -0.11458,0.8125 -0.10417,0.27084 -0.29167,0.27084 h -1.19792 v 2.4375 q 0,0.10416 -0.0625,0.1875 -0.0625,0.0729 -0.21875,0.125 -0.15625,0.0521 -0.40625,0.0729 -0.25,0.0312 -0.64583,0.0312 -0.375,0 -0.63542,-0.0312 -0.25,-0.0208 -0.40625,-0.0729 -0.14583,-0.0521 -0.20833,-0.125 -0.0521,-0.0833 -0.0521,-0.1875 v -2.4375 h -5.15625 q -0.14584,0 -0.26042,-0.0312 -0.11458,-0.0417 -0.19792,-0.16667 -0.0729,-0.13542 -0.11458,-0.375 -0.0312,-0.25 -0.0312,-0.65625 0,-0.33333 0.0104,-0.57292 0.0208,-0.25 0.0521,-0.44791 0.0417,-0.19792 0.10417,-0.375 0.0729,-0.17709 0.17708,-0.375 l 4.1875,-7.38542 q 0.0521,-0.0937 0.17708,-0.15625 0.125,-0.0729 0.34375,-0.11458 0.22917,-0.0521 0.57292,-0.0729 0.34375,-0.0208 0.83333,-0.0208 0.53125,0 0.90625,0.0312 0.375,0.0208 0.59375,0.0833 0.22917,0.0521 0.33334,0.13542 0.10416,0.0833 0.10416,0.19791 v 8.11459 h 1.19792 q 0.16667,0 0.28125,0.26041 0.125,0.25 0.125,0.84375 z m -4.23958,-7.30208 h -0.0208 l -3.55208,6.19792 h 3.57292 z"/>
                                    <path id="path3154" style={{
                                        "fontStyle": "normal",
                                        "fontVariant": "normal",
                                        "fontWeight": "bold",
                                        "fontStretch": "normal",
                                        "fontSize": "21.33333397px",
                                        "fontFamily": "Calibri",
                                        "InkscapeFontSpecification": "'Calibri Bold'",
                                        "fill": "#ffffff"
                                    }}
                                          d="m 191.93159,377.95974 q 0,1.61458 -0.26042,2.91666 -0.26041,1.30209 -0.85416,2.21875 -0.58334,0.91667 -1.53125,1.40625 -0.9375,0.48959 -2.30209,0.48959 -1.38541,0 -2.29166,-0.46875 -0.90625,-0.47917 -1.4375,-1.36459 -0.53125,-0.89583 -0.75,-2.17708 -0.20834,-1.29167 -0.20834,-2.91667 0,-1.60416 0.26042,-2.90625 0.27083,-1.3125 0.85417,-2.22916 0.59375,-0.91667 1.53125,-1.40625 0.94791,-0.48959 2.30208,-0.48959 1.38542,0 2.29167,0.47917 0.91666,0.46875 1.44791,1.36458 0.53125,0.88542 0.73959,2.17709 0.20833,1.28125 0.20833,2.90625 z m -2.76042,0.13541 q 0,-0.95833 -0.0521,-1.6875 -0.0521,-0.73958 -0.16667,-1.28125 -0.10416,-0.54166 -0.27083,-0.91666 -0.15625,-0.375 -0.38542,-0.59375 -0.22916,-0.22917 -0.52083,-0.32292 -0.29167,-0.0937 -0.64583,-0.0937 -0.61459,0 -1.02084,0.30208 -0.39583,0.29167 -0.63541,0.88542 -0.22917,0.59375 -0.32292,1.47917 -0.0937,0.88541 -0.0937,2.0625 0,1.4375 0.11458,2.38541 0.11459,0.9375 0.35417,1.5 0.25,0.55209 0.63542,0.78125 0.38541,0.21875 0.92708,0.21875 0.40625,0 0.71875,-0.125 0.3125,-0.13541 0.54167,-0.39583 0.23958,-0.26042 0.39583,-0.65625 0.15625,-0.39583 0.25,-0.91667 0.10417,-0.52083 0.13542,-1.17708 0.0417,-0.65625 0.0417,-1.44792 z"/>
                                </g>
                                <g id="text2857-24-5-1-7-1" style={{
                                    "fontStyle": "normal",
                                    "fontWeight": "normal",
                                    "fontSize": "32px",
                                    "lineHeight": "1.25",
                                    "fontFamily": "sans-serif",
                                    "letterSpacing": "0px",
                                    "wordSpacing": "0px",
                                    "fill": "#000000",
                                    "fillOpacity": "1",
                                    "stroke": "none"
                                }}>
                                    <path id="path3157" style={{
                                        "fontStyle": "normal",
                                        "fontVariant": "normal",
                                        "fontWeight": "bold",
                                        "fontStretch": "normal",
                                        "fontSize": "21.33333397px",
                                        "fontFamily": "Calibri",
                                        "InkscapeFontSpecification": "'Calibri Bold'",
                                        "fill": "#ffffff"
                                    }}
                                          d="m 313.55241,379.37663 q 0,0.60416 -0.11458,0.84375 -0.11459,0.23958 -0.36459,0.23958 h -4.33333 q -0.26042,0 -0.375,-0.23958 -0.11458,-0.25 -0.11458,-0.84375 0,-0.58334 0.11458,-0.82292 0.11458,-0.23958 0.375,-0.23958 h 4.33333 q 0.125,0 0.20834,0.0521 0.0937,0.0521 0.15625,0.17708 0.0625,0.125 0.0833,0.33334 0.0312,0.20833 0.0312,0.5 z"/>
                                    <path id="path3159" style={{
                                        "fontStyle": "normal",
                                        "fontVariant": "normal",
                                        "fontWeight": "bold",
                                        "fontStretch": "normal",
                                        "fontSize": "21.33333397px",
                                        "fontFamily": "Calibri",
                                        "InkscapeFontSpecification": "'Calibri Bold'",
                                        "fill": "#ffffff"
                                    }}
                                          d="m 324.55241,380.74121 q 0,0.53125 -0.11458,0.8125 -0.10417,0.27083 -0.29167,0.27083 h -1.19792 v 2.4375 q 0,0.10417 -0.0625,0.1875 -0.0625,0.0729 -0.21875,0.125 -0.15625,0.0521 -0.40625,0.0729 -0.25,0.0312 -0.64583,0.0312 -0.375,0 -0.63542,-0.0312 -0.25,-0.0208 -0.40625,-0.0729 -0.14583,-0.0521 -0.20833,-0.125 -0.0521,-0.0833 -0.0521,-0.1875 v -2.4375 h -5.15625 q -0.14584,0 -0.26042,-0.0312 -0.11458,-0.0417 -0.19792,-0.16666 -0.0729,-0.13542 -0.11458,-0.375 -0.0312,-0.25 -0.0312,-0.65625 0,-0.33334 0.0104,-0.57292 0.0208,-0.25 0.0521,-0.44792 0.0417,-0.19791 0.10417,-0.375 0.0729,-0.17708 0.17708,-0.375 l 4.1875,-7.38541 q 0.0521,-0.0937 0.17708,-0.15625 0.125,-0.0729 0.34375,-0.11459 0.22917,-0.0521 0.57292,-0.0729 0.34375,-0.0208 0.83333,-0.0208 0.53125,0 0.90625,0.0312 0.375,0.0208 0.59375,0.0833 0.22917,0.0521 0.33334,0.13541 0.10416,0.0833 0.10416,0.19792 v 8.11458 h 1.19792 q 0.16667,0 0.28125,0.26042 0.125,0.25 0.125,0.84375 z m -4.23958,-7.30208 h -0.0208 l -3.55208,6.19791 h 3.57292 z"/>
                                    <path id="path3161" style={{
                                        "fontStyle": "normal",
                                        "fontVariant": "normal",
                                        "fontWeight": "bold",
                                        "fontStretch": "normal",
                                        "fontSize": "21.33333397px",
                                        "fontFamily": "Calibri",
                                        "InkscapeFontSpecification": "'Calibri Bold'",
                                        "fill": "#ffffff"
                                    }}
                                          d="m 335.23991,377.82454 q 0,1.61459 -0.26042,2.91667 -0.26041,1.30208 -0.85416,2.21875 -0.58334,0.91667 -1.53125,1.40625 -0.9375,0.48958 -2.30209,0.48958 -1.38541,0 -2.29166,-0.46875 -0.90625,-0.47916 -1.4375,-1.36458 -0.53125,-0.89583 -0.75,-2.17708 -0.20834,-1.29167 -0.20834,-2.91667 0,-1.60417 0.26042,-2.90625 0.27083,-1.3125 0.85417,-2.22917 0.59375,-0.91666 1.53125,-1.40625 0.94791,-0.48958 2.30208,-0.48958 1.38542,0 2.29167,0.47917 0.91666,0.46875 1.44791,1.36458 0.53125,0.88542 0.73959,2.17708 0.20833,1.28125 0.20833,2.90625 z m -2.76042,0.13542 q 0,-0.95833 -0.0521,-1.6875 -0.0521,-0.73958 -0.16667,-1.28125 -0.10416,-0.54167 -0.27083,-0.91667 -0.15625,-0.375 -0.38542,-0.59375 -0.22916,-0.22916 -0.52083,-0.32291 -0.29167,-0.0937 -0.64583,-0.0937 -0.61459,0 -1.02084,0.30208 -0.39583,0.29167 -0.63541,0.88542 -0.22917,0.59375 -0.32292,1.47916 -0.0937,0.88542 -0.0937,2.0625 0,1.4375 0.11458,2.38542 0.11459,0.9375 0.35417,1.5 0.25,0.55208 0.63542,0.78125 0.38541,0.21875 0.92708,0.21875 0.40625,0 0.71875,-0.125 0.3125,-0.13542 0.54167,-0.39583 0.23958,-0.26042 0.39583,-0.65625 0.15625,-0.39584 0.25,-0.91667 0.10417,-0.52083 0.13542,-1.17708 0.0417,-0.65625 0.0417,-1.44792 z"/>
                                </g>
                            </g>
                        </motion.g>
                        <g id="g42067-7" style={{"opacity": "0.956"}}
                           transform="matrix(1.0734245,0,0,1.0741204,473.51343,-2.7964427)">
                            <ellipse id="path38921-9-6-1" style={{
                                "fill": "#666666",
                                "fillOpacity": "1",
                                "stroke": "#000000",
                                "strokeWidth": "2.0000875",
                                "strokeLinejoin": "miter",
                                "strokeMiterlimit": "4",
                                "strokeDasharray": "none",
                                "strokeOpacity": "1"
                            }} cx="-14.1902" cy="14.956068" rx="6.5041161" ry="6.5043001"
                                     transform="matrix(-0.99989621,0.0144075,0.00117667,0.99999931,0,0)"/>
                            <g id="use41884-4-2-2"
                               transform="matrix(-0.12354746,0.0017802,1.4539402e-4,0.12356369,18.576861,8.6977977)">
                                <title id="title3471">Times</title>
                                <path id="path3473"
                                      d="m 1298,214 q 0,-40 -28,-68 L 1134,10 q -28,-28 -68,-28 -40,0 -68,28 L 704,304 410,10 q -28,-28 -68,-28 -40,0 -68,28 L 138,146 q -28,28 -28,68 0,40 28,68 L 432,576 138,870 q -28,28 -28,68 0,40 28,68 l 136,136 q 28,28 68,28 40,0 68,-28 l 294,-294 294,294 q 28,28 68,28 40,0 68,-28 l 136,-136 q 28,-28 28,-68 0,-40 -28,-68 L 976,576 1270,282 q 28,-28 28,-68 z"
                                      transform="matrix(0.05,0,0,-0.05,0,76.8)"/>
                            </g>
                        </g>
                        <g id="g42067-7-4" style={{"opacity": "0.956"}}
                           transform="matrix(1.0734245,0,0,1.0741204,-3.4087503,-2.131654)">
                            <ellipse id="path38921-9-6-1-5" style={{
                                "fill": "#666666",
                                "fillOpacity": "1",
                                "stroke": "#000000",
                                "strokeWidth": "2.0000875",
                                "strokeLinejoin": "miter",
                                "strokeMiterlimit": "4",
                                "strokeDasharray": "none",
                                "strokeOpacity": "1"
                            }} cx="-14.1902" cy="14.956068" rx="6.5041161" ry="6.5043001"
                                     transform="matrix(-0.99989621,0.0144075,0.00117667,0.99999931,0,0)"/>
                            <g id="use41884-4-2-2-3"
                               transform="matrix(-0.12354746,0.0017802,1.4539402e-4,0.12356369,18.576861,8.6977977)">
                                <title id="title3490">Times</title>
                                <path id="path3492"
                                      d="m 1298,214 q 0,-40 -28,-68 L 1134,10 q -28,-28 -68,-28 -40,0 -68,28 L 704,304 410,10 q -28,-28 -68,-28 -40,0 -68,28 L 138,146 q -28,28 -28,68 0,40 28,68 L 432,576 138,870 q -28,28 -28,68 0,40 28,68 l 136,136 q 28,28 68,28 40,0 68,-28 l 294,-294 294,294 q 28,28 68,28 40,0 68,-28 l 136,-136 q 28,-28 28,-68 0,-40 -28,-68 L 976,576 1270,282 q 28,-28 28,-68 z"
                                      transform="matrix(0.05,0,0,-0.05,0,76.8)"/>
                            </g>
                        </g>
                        <g id="g42067-7-2" style={{"opacity": "0.956"}}
                           transform="matrix(1.0734245,0,0,1.0741204,-3.0104505,471.91149)">
                            <ellipse id="path38921-9-6-1-3" style={{
                                "fill": "#666666",
                                "fillOpacity": "1",
                                "stroke": "#000000",
                                "strokeWidth": "2.0000875",
                                "strokeLinejoin": "miter",
                                "strokeMiterlimit": "4",
                                "strokeDasharray": "none",
                                "strokeOpacity": "1"
                            }} cx="-14.1902" cy="14.956068" rx="6.5041161" ry="6.5043001"
                                     transform="matrix(-0.99989621,0.0144075,0.00117667,0.99999931,0,0)"/>
                            <g id="use41884-4-2-2-0"
                               transform="matrix(-0.12354746,0.0017802,1.4539402e-4,0.12356369,18.576861,8.6977977)">
                                <title id="title3509">Times</title>
                                <path id="path3511"
                                      d="m 1298,214 q 0,-40 -28,-68 L 1134,10 q -28,-28 -68,-28 -40,0 -68,28 L 704,304 410,10 q -28,-28 -68,-28 -40,0 -68,28 L 138,146 q -28,28 -28,68 0,40 28,68 L 432,576 138,870 q -28,28 -28,68 0,40 28,68 l 136,136 q 28,28 68,28 40,0 68,-28 l 294,-294 294,294 q 28,28 68,28 40,0 68,-28 l 136,-136 q 28,-28 28,-68 0,-40 -28,-68 L 976,576 1270,282 q 28,-28 28,-68 z"
                                      transform="matrix(0.05,0,0,-0.05,0,76.8)"/>
                            </g>
                        </g>
                        <g id="g42067-7-8" style={{"opacity": "0.956"}}
                           transform="matrix(1.0734245,0,0,1.0741204,474.42713,472.0717)">
                            <ellipse id="path38921-9-6-1-2" style={{
                                "fill": "#666666",
                                "fillOpacity": "1",
                                "stroke": "#000000",
                                "strokeWidth": "2.0000875",
                                "strokeLinejoin": "miter",
                                "strokeMiterlimit": "4",
                                "strokeDasharray": "none",
                                "strokeOpacity": "1"
                            }} cx="-14.1902" cy="14.956068" rx="6.5041161" ry="6.5043001"
                                     transform="matrix(-0.99989621,0.0144075,0.00117667,0.99999931,0,0)"/>
                            <g id="use41884-4-2-2-2"
                               transform="matrix(-0.12354746,0.0017802,1.4539402e-4,0.12356369,18.576861,8.6977977)">
                                <title id="title3471-1">Times</title>
                                <path id="path3473-5"
                                      d="m 1298,214 q 0,-40 -28,-68 L 1134,10 q -28,-28 -68,-28 -40,0 -68,28 L 704,304 410,10 q -28,-28 -68,-28 -40,0 -68,28 L 138,146 q -28,28 -28,68 0,40 28,68 L 432,576 138,870 q -28,28 -28,68 0,40 28,68 l 136,136 q 28,28 68,28 40,0 68,-28 l 294,-294 294,294 q 28,28 68,28 40,0 68,-28 l 136,-136 q 28,-28 28,-68 0,-40 -28,-68 L 976,576 1270,282 q 28,-28 28,-68 z"
                                      transform="matrix(0.05,0,0,-0.05,0,76.8)"/>
                            </g>
                        </g>
                        <g id="g42067-7-4-0" style={{"opacity": "0.956"}}
                           transform="matrix(1.0734245,0,0,1.0741204,-3.4129954,234.10958)">
                            <ellipse id="path38921-9-6-1-5-9" style={{
                                "fill": "#666666",
                                "fillOpacity": "1",
                                "stroke": "#000000",
                                "strokeWidth": "2.0000875",
                                "strokeLinejoin": "miter",
                                "strokeMiterlimit": "4",
                                "strokeDasharray": "none",
                                "strokeOpacity": "1"
                            }} cx="-14.1902" cy="14.956068" rx="6.5041161" ry="6.5043001"
                                     transform="matrix(-0.99989621,0.0144075,0.00117667,0.99999931,0,0)"/>
                            <g id="use41884-4-2-2-3-8"
                               transform="matrix(-0.12354746,0.0017802,1.4539402e-4,0.12356369,18.576861,8.6977977)">
                                <title id="title3490-8">Times</title>
                                <path id="path3492-5"
                                      d="m 1298,214 q 0,-40 -28,-68 L 1134,10 q -28,-28 -68,-28 -40,0 -68,28 L 704,304 410,10 q -28,-28 -68,-28 -40,0 -68,28 L 138,146 q -28,28 -28,68 0,40 28,68 L 432,576 138,870 q -28,28 -28,68 0,40 28,68 l 136,136 q 28,28 68,28 40,0 68,-28 l 294,-294 294,294 q 28,28 68,28 40,0 68,-28 l 136,-136 q 28,-28 28,-68 0,-40 -28,-68 L 976,576 1270,282 q 28,-28 28,-68 z"
                                      transform="matrix(0.05,0,0,-0.05,0,76.8)"/>
                            </g>
                        </g>
                        <g id="g42067-7-4-1" style={{"opacity": "0.956"}}
                           transform="matrix(1.0734245,0,0,1.0741204,473.38325,234.11958)">
                            <ellipse id="path38921-9-6-1-5-3" style={{
                                "fill": "#666666",
                                "fillOpacity": "1",
                                "stroke": "#000000",
                                "strokeWidth": "2.0000875",
                                "strokeLinejoin": "miter",
                                "strokeMiterlimit": "4",
                                "strokeDasharray": "none",
                                "strokeOpacity": "1"
                            }} cx="-14.1902" cy="14.956068" rx="6.5041161" ry="6.5043001"
                                     transform="matrix(-0.99989621,0.0144075,0.00117667,0.99999931,0,0)"/>
                            <g id="use41884-4-2-2-3-0"
                               transform="matrix(-0.12354746,0.0017802,1.4539402e-4,0.12356369,18.576861,8.6977977)">
                                <title id="title3490-0">Times</title>
                                <path id="path3492-2"
                                      d="m 1298,214 q 0,-40 -28,-68 L 1134,10 q -28,-28 -68,-28 -40,0 -68,28 L 704,304 410,10 q -28,-28 -68,-28 -40,0 -68,28 L 138,146 q -28,28 -28,68 0,40 28,68 L 432,576 138,870 q -28,28 -28,68 0,40 28,68 l 136,136 q 28,28 68,28 40,0 68,-28 l 294,-294 294,294 q 28,28 68,28 40,0 68,-28 l 136,-136 q 28,-28 28,-68 0,-40 -28,-68 L 976,576 1270,282 q 28,-28 28,-68 z"
                                      transform="matrix(0.05,0,0,-0.05,0,76.8)"/>
                            </g>
                        </g>
                        <g id="g42067-7-4-08" style={{"opacity": "0.956"}}
                           transform="matrix(1.0734245,0,0,1.0741204,234.7359,-2.1949143)">
                            <ellipse id="path38921-9-6-1-5-0" style={{
                                "fill": "#666666",
                                "fillOpacity": "1",
                                "stroke": "#000000",
                                "strokeWidth": "2.0000875",
                                "strokeLinejoin": "miter",
                                "strokeMiterlimit": "4",
                                "strokeDasharray": "none",
                                "strokeOpacity": "1"
                            }} cx="-14.1902" cy="14.956068" rx="6.5041161" ry="6.5043001"
                                     transform="matrix(-0.99989621,0.0144075,0.00117667,0.99999931,0,0)"/>
                            <g id="use41884-4-2-2-3-2"
                               transform="matrix(-0.12354746,0.0017802,1.4539402e-4,0.12356369,18.576861,8.6977977)">
                                <title id="title3490-5">Times</title>
                                <path id="path3492-3"
                                      d="m 1298,214 q 0,-40 -28,-68 L 1134,10 q -28,-28 -68,-28 -40,0 -68,28 L 704,304 410,10 q -28,-28 -68,-28 -40,0 -68,28 L 138,146 q -28,28 -28,68 0,40 28,68 L 432,576 138,870 q -28,28 -28,68 0,40 28,68 l 136,136 q 28,28 68,28 40,0 68,-28 l 294,-294 294,294 q 28,28 68,28 40,0 68,-28 l 136,-136 q 28,-28 28,-68 0,-40 -28,-68 L 976,576 1270,282 q 28,-28 28,-68 z"
                                      transform="matrix(0.05,0,0,-0.05,0,76.8)"/>
                            </g>
                        </g>
                        <g id="g42067-7-4-9" style={{"opacity": "0.956"}}
                           transform="matrix(1.0734245,0,0,1.0741204,234.8359,472.0717)">
                            <ellipse id="path38921-9-6-1-5-06" style={{
                                "fill": "#666666",
                                "fillOpacity": "1",
                                "stroke": "#000000",
                                "strokeWidth": "2.0000875",
                                "strokeLinejoin": "miter",
                                "strokeMiterlimit": "4",
                                "strokeDasharray": "none",
                                "strokeOpacity": "1"
                            }} cx="-14.1902" cy="14.956068" rx="6.5041161" ry="6.5043001"
                                     transform="matrix(-0.99989621,0.0144075,0.00117667,0.99999931,0,0)"/>
                            <g id="use41884-4-2-2-3-1"
                               transform="matrix(-0.12354746,0.0017802,1.4539402e-4,0.12356369,18.576861,8.6977977)">
                                <title id="title3490-2">Times</title>
                                <path id="path3492-9"
                                      d="m 1298,214 q 0,-40 -28,-68 L 1134,10 q -28,-28 -68,-28 -40,0 -68,28 L 704,304 410,10 q -28,-28 -68,-28 -40,0 -68,28 L 138,146 q -28,28 -28,68 0,40 28,68 L 432,576 138,870 q -28,28 -28,68 0,40 28,68 l 136,136 q 28,28 68,28 40,0 68,-28 l 294,-294 294,294 q 28,28 68,28 40,0 68,-28 l 136,-136 q 28,-28 28,-68 0,-40 -28,-68 L 976,576 1270,282 q 28,-28 28,-68 z"
                                      transform="matrix(0.05,0,0,-0.05,0,76.8)"/>
                            </g>
                        </g>
                        <g id="g3423">
                            <rect height="6" id="rect3375" style={{
                                "fill": "#ff7f00",
                                "fillOpacity": "1",
                                "stroke": "none",
                                "strokeWidth": "5",
                                "strokeLinecap": "round",
                                "strokeLinejoin": "round",
                                "strokeMiterlimit": "4",
                                "strokeDasharray": "none",
                                "strokeDashoffset": "0",
                                "strokeOpacity": "1"
                            }} width="112.76276" x="112.23724" y="247.05299"/>
                            <rect height="6" id="rect3375-5" style={{
                                "fill": "#ff7f00",
                                "fillOpacity": "1",
                                "stroke": "none",
                                "strokeWidth": "5",
                                "strokeLinecap": "round",
                                "strokeLinejoin": "round",
                                "strokeMiterlimit": "4",
                                "strokeDasharray": "none",
                                "strokeDashoffset": "0",
                                "strokeOpacity": "1"
                            }} width="112.76276" x="275.11862" y="247.095"/>
                            <path id="path3396" style={{
                                "fill": "#ff7f00",
                                "fillOpacity": "1",
                                "stroke": "none",
                                "strokeWidth": "5",
                                "strokeLinecap": "round",
                                "strokeLinejoin": "round",
                                "strokeMiterlimit": "4",
                                "strokeDasharray": "none",
                                "strokeDashoffset": "0",
                                "strokeOpacity": "1"
                            }}
                                  d="M 249.875 239.96289 A 10 10 0 0 0 240 250.04492 A 10 10 0 0 0 250.04102 259.96289 A 10 10 0 0 0 260 249.96289 L 259.99805 249.79492 A 10 10 0 0 0 249.875 239.96289 z M 249.97852 244.97852 A 5 5 0 0 1 255.04102 249.89453 L 255.04102 249.97852 A 5 5 0 0 1 250.0625 254.97852 A 5 5 0 0 1 245.04102 250.02148 A 5 5 0 0 1 249.97852 244.97852 z "/>
                            <path id="path3398" style={{
                                "fill": "none",
                                "stroke": "#ff7f00",
                                "strokeWidth": "6",
                                "strokeLinecap": "butt",
                                "strokeLinejoin": "miter",
                                "strokeMiterlimit": "4",
                                "strokeDasharray": "none",
                                "strokeOpacity": "1"
                            }}
                                  d="m 222.72733,248.91702 c 9.09505,11.31888 18.19006,22.63772 27.3149,22.64637 9.12484,0.009 18.278,-11.2919 27.4304,-22.59153"/>
                        </g>
                        <g id="text1033" style={{
                            "fontStyle": "normal",
                            "fontWeight": "normal",
                            "fontSize": "32px",
                            "lineHeight": "1.25",
                            "fontFamily": "sans-serif",
                            "letterSpacing": "0px",
                            "wordSpacing": "0px",
                            "fill": "#000000",
                            "fillOpacity": "1",
                            "stroke": "none"
                        }}>
                            <path id="path1134" style={{
                                "fontStyle": "normal",
                                "fontVariant": "normal",
                                "fontWeight": "bold",
                                "fontStretch": "normal",
                                "fontSize": "21.33333397px",
                                "fontFamily": "Calibri",
                                "InkscapeFontSpecification": "'Calibri Bold'",
                                "fill": "#ffffff"
                            }}
                                  d="m 60.498168,48.314832 q 0,1.135416 -0.354167,2.010416 -0.354166,0.875001 -1.03125,1.479167 -0.677083,0.59375 -1.666666,0.90625 -0.979167,0.3125 -2.312501,0.3125 h -1.125 v 4.302084 q 0,0.104166 -0.07292,0.1875 -0.0625,0.08333 -0.21875,0.135416 -0.15625,0.05208 -0.416667,0.08333 -0.260417,0.03125 -0.666667,0.03125 -0.395833,0 -0.666666,-0.03125 -0.260417,-0.03125 -0.416667,-0.08333 -0.15625,-0.05208 -0.21875,-0.135416 -0.0625,-0.08333 -0.0625,-0.1875 V 45.200248 q 0,-0.489583 0.25,-0.729166 0.260417,-0.25 0.677083,-0.25 h 3.177084 q 0.479167,0 0.90625,0.04167 0.4375,0.03125 1.041667,0.15625 0.604166,0.114584 1.21875,0.4375 0.625,0.322917 1.0625,0.822917 0.4375,0.489583 0.666666,1.15625 0.229167,0.65625 0.229167,1.479167 z m -2.864583,0.197916 q 0,-0.708333 -0.25,-1.166666 -0.25,-0.458334 -0.614584,-0.677084 -0.364583,-0.21875 -0.770833,-0.270833 -0.395833,-0.0625 -0.822917,-0.0625 h -1.166667 v 4.572917 h 1.229167 q 0.65625,0 1.09375,-0.177083 0.447917,-0.177084 0.729167,-0.489584 0.28125,-0.322917 0.427083,-0.760417 0.145834,-0.447916 0.145834,-0.96875 z"/>
                            <path id="path1136" style={{
                                "fontStyle": "normal",
                                "fontVariant": "normal",
                                "fontWeight": "bold",
                                "fontStretch": "normal",
                                "fontSize": "21.33333397px",
                                "fontFamily": "Calibri",
                                "InkscapeFontSpecification": "'Calibri Bold'",
                                "fill": "#ffffff"
                            }}
                                  d="m 65.394001,57.325249 q 0,0.104166 -0.07292,0.1875 -0.0625,0.08333 -0.21875,0.135416 -0.15625,0.05208 -0.416666,0.08333 -0.260417,0.03125 -0.666667,0.03125 -0.395833,0 -0.666667,-0.03125 -0.260416,-0.03125 -0.416666,-0.08333 -0.15625,-0.05208 -0.229167,-0.135416 -0.0625,-0.08333 -0.0625,-0.1875 V 44.596082 q 0,-0.104167 0.0625,-0.1875 0.07292,-0.08333 0.229167,-0.135417 0.166666,-0.05208 0.427083,-0.08333 0.260417,-0.03125 0.65625,-0.03125 0.40625,0 0.666667,0.03125 0.260416,0.03125 0.416666,0.08333 0.15625,0.05208 0.21875,0.135417 0.07292,0.08333 0.07292,0.1875 z"/>
                            <path id="path1138" style={{
                                "fontStyle": "normal",
                                "fontVariant": "normal",
                                "fontWeight": "bold",
                                "fontStretch": "normal",
                                "fontSize": "21.33333397px",
                                "fontFamily": "Calibri",
                                "InkscapeFontSpecification": "'Calibri Bold'",
                                "fill": "#ffffff"
                            }}
                                  d="m 77.321085,45.346082 q 0,0.302083 -0.03125,0.520833 -0.02083,0.208333 -0.07292,0.34375 -0.05208,0.125 -0.135417,0.1875 -0.07292,0.0625 -0.166667,0.0625 h -3.375 v 10.864584 q 0,0.104166 -0.07292,0.1875 -0.0625,0.08333 -0.218751,0.135416 -0.15625,0.05208 -0.427083,0.08333 -0.260417,0.03125 -0.65625,0.03125 -0.395833,0 -0.666667,-0.03125 -0.260416,-0.03125 -0.416666,-0.08333 -0.15625,-0.05208 -0.229167,-0.135416 -0.0625,-0.08333 -0.0625,-0.1875 V 46.460665 h -3.375 q -0.104167,0 -0.177083,-0.0625 -0.07292,-0.0625 -0.125,-0.1875 -0.05208,-0.135417 -0.08333,-0.34375 -0.02083,-0.21875 -0.02083,-0.520833 0,-0.3125 0.02083,-0.53125 0.03125,-0.21875 0.08333,-0.34375 0.05208,-0.135417 0.125,-0.1875 0.07292,-0.0625 0.177083,-0.0625 h 9.5 q 0.09375,0 0.166667,0.0625 0.08333,0.05208 0.135417,0.1875 0.05208,0.125 0.07292,0.34375 0.03125,0.21875 0.03125,0.53125 z"/>
                            <path id="path1140" style={{
                                "fontStyle": "normal",
                                "fontVariant": "normal",
                                "fontWeight": "bold",
                                "fontStretch": "normal",
                                "fontSize": "21.33333397px",
                                "fontFamily": "Calibri",
                                "InkscapeFontSpecification": "'Calibri Bold'",
                                "fill": "#ffffff"
                            }}
                                  d="m 87.800252,55.658582 q 0,0.260417 -0.02083,0.447917 -0.01042,0.177083 -0.04167,0.3125 -0.03125,0.125 -0.08333,0.21875 -0.05208,0.09375 -0.166667,0.21875 -0.114583,0.114583 -0.447917,0.302083 -0.322916,0.1875 -0.802083,0.364583 -0.46875,0.166667 -1.083333,0.28125 -0.604167,0.114584 -1.3125,0.114584 -1.385417,0 -2.500001,-0.427084 -1.114583,-0.427083 -1.895833,-1.270833 -0.78125,-0.854167 -1.197917,-2.125 -0.416666,-1.270833 -0.416666,-2.958333 0,-1.718751 0.458333,-3.052084 0.458333,-1.333333 1.28125,-2.239583 0.822917,-0.90625 1.96875,-1.375 1.15625,-0.46875 2.541667,-0.46875 0.5625,0 1.083333,0.09375 0.520834,0.09375 0.958334,0.25 0.447916,0.145833 0.802083,0.34375 0.354167,0.197916 0.489583,0.34375 0.145834,0.135416 0.197917,0.229166 0.05208,0.09375 0.08333,0.239584 0.03125,0.145833 0.04167,0.34375 0.02083,0.197916 0.02083,0.489583 0,0.3125 -0.02083,0.53125 -0.02083,0.21875 -0.07292,0.354167 -0.05208,0.135416 -0.125,0.197916 -0.07292,0.0625 -0.166666,0.0625 -0.15625,0 -0.395834,-0.177083 -0.239583,-0.1875 -0.625,-0.40625 -0.375,-0.229167 -0.90625,-0.40625 -0.520833,-0.1875 -1.25,-0.1875 -0.802083,0 -1.4375,0.333333 -0.625,0.322917 -1.072917,0.9375 -0.4375,0.604167 -0.666666,1.46875 -0.229167,0.864584 -0.229167,1.947917 0,1.1875 0.239583,2.0625 0.25,0.864584 0.697917,1.427084 0.458333,0.5625 1.09375,0.84375 0.645834,0.270833 1.447917,0.270833 0.729167,0 1.260417,-0.166667 0.53125,-0.177083 0.90625,-0.385416 0.385416,-0.208334 0.625,-0.375 0.25,-0.166667 0.385416,-0.166667 0.104167,0 0.166667,0.04167 0.0625,0.04167 0.104167,0.166666 0.04167,0.125 0.0625,0.354167 0.02083,0.21875 0.02083,0.59375 z"/>
                            <path id="path1142" style={{
                                "fontStyle": "normal",
                                "fontVariant": "normal",
                                "fontWeight": "bold",
                                "fontStretch": "normal",
                                "fontSize": "21.33333397px",
                                "fontFamily": "Calibri",
                                "InkscapeFontSpecification": "'Calibri Bold'",
                                "fill": "#ffffff"
                            }}
                                  d="m 100.28983,57.325249 q 0,0.104166 -0.0729,0.1875 -0.0625,0.08333 -0.218752,0.135416 -0.15625,0.05208 -0.416667,0.08333 -0.260416,0.03125 -0.65625,0.03125 -0.40625,0 -0.677083,-0.03125 -0.260417,-0.03125 -0.416667,-0.08333 -0.145833,-0.05208 -0.21875,-0.135416 -0.0625,-0.08333 -0.0625,-0.1875 v -5.447917 h -5.041667 v 5.447917 q 0,0.104166 -0.0625,0.1875 -0.0625,0.08333 -0.21875,0.135416 -0.15625,0.05208 -0.416666,0.08333 -0.260417,0.03125 -0.666667,0.03125 -0.395833,0 -0.666667,-0.03125 -0.260416,-0.03125 -0.416666,-0.08333 -0.15625,-0.05208 -0.229167,-0.135416 -0.0625,-0.08333 -0.0625,-0.1875 V 44.596082 q 0,-0.104167 0.0625,-0.1875 0.07292,-0.08333 0.229167,-0.135417 0.15625,-0.05208 0.416666,-0.08333 0.270834,-0.03125 0.666667,-0.03125 0.40625,0 0.666667,0.03125 0.260416,0.03125 0.416666,0.08333 0.15625,0.05208 0.21875,0.135417 0.0625,0.08333 0.0625,0.1875 v 4.947916 h 5.041667 v -4.947916 q 0,-0.104167 0.0625,-0.1875 0.07292,-0.08333 0.21875,-0.135417 0.15625,-0.05208 0.416667,-0.08333 0.270833,-0.03125 0.677083,-0.03125 0.395834,0 0.65625,0.03125 0.260417,0.03125 0.416667,0.08333 0.156252,0.05208 0.218752,0.135417 0.0729,0.08333 0.0729,0.1875 z"/>
                        </g>
                        <g id="text1033-9" style={{
                            "fontStyle": "normal",
                            "fontWeight": "normal",
                            "fontSize": "32px",
                            "lineHeight": "1.25",
                            "fontFamily": "sans-serif",
                            "letterSpacing": "0px",
                            "wordSpacing": "0px",
                            "fill": "#000000",
                            "fillOpacity": "1",
                            "stroke": "none"
                        }}>
                            <path id="path1125" style={{
                                "fontStyle": "normal",
                                "fontVariant": "normal",
                                "fontWeight": "bold",
                                "fontStretch": "normal",
                                "fontSize": "21.33333397px",
                                "fontFamily": "Calibri",
                                "InkscapeFontSpecification": "'Calibri Bold'",
                                "fill": "#ffffff"
                            }}
                                  d="m 400.92001,57.421083 q 0,0.114583 -0.0417,0.197916 -0.0417,0.07292 -0.19792,0.125 -0.15625,0.05208 -0.45833,0.07292 -0.30209,0.02083 -0.82292,0.02083 -0.4375,0 -0.69792,-0.02083 -0.26041,-0.02083 -0.41666,-0.07292 -0.14584,-0.0625 -0.20834,-0.145833 -0.0625,-0.09375 -0.10416,-0.21875 l -1.20834,-3.010417 q -0.21875,-0.510416 -0.42708,-0.90625 -0.20833,-0.395833 -0.46875,-0.65625 -0.25,-0.270833 -0.58333,-0.40625 -0.33334,-0.135416 -0.77084,-0.135416 h -0.85416 v 5.135416 q 0,0.104167 -0.0729,0.1875 -0.0625,0.08333 -0.21875,0.135417 -0.15625,0.05208 -0.41667,0.08333 -0.26041,0.03125 -0.66666,0.03125 -0.39584,0 -0.66667,-0.03125 -0.26042,-0.03125 -0.41667,-0.08333 -0.15625,-0.05208 -0.21875,-0.135417 -0.0625,-0.08333 -0.0625,-0.1875 V 45.160666 q 0,-0.458334 0.22917,-0.65625 0.23958,-0.208334 0.58333,-0.208334 h 3.48959 q 0.53125,0 0.875,0.02083 0.34375,0.02083 0.625,0.05208 0.8125,0.114583 1.45833,0.395833 0.65625,0.28125 1.10417,0.739584 0.45833,0.447916 0.69791,1.072916 0.23959,0.614584 0.23959,1.416667 0,0.677084 -0.17709,1.239584 -0.16666,0.552083 -0.5,0.989583 -0.33333,0.4375 -0.82291,0.760417 -0.48959,0.322916 -1.11459,0.520833 0.30209,0.145833 0.5625,0.354167 0.27084,0.208333 0.5,0.510416 0.23959,0.291667 0.44792,0.677084 0.20833,0.375 0.40625,0.854166 l 1.13542,2.65625 q 0.15625,0.395834 0.20833,0.583334 0.0521,0.177083 0.0521,0.28125 z m -3.53125,-9.145834 q 0,-0.666666 -0.30208,-1.125 -0.30208,-0.458333 -0.98958,-0.645833 -0.20834,-0.05208 -0.47917,-0.08333 -0.26042,-0.03125 -0.72917,-0.03125 h -1.22916 v 3.822917 h 1.39583 q 0.58333,0 1.02083,-0.135416 0.4375,-0.145834 0.72917,-0.395834 0.29167,-0.260416 0.4375,-0.614583 0.14583,-0.354167 0.14583,-0.791667 z"/>
                            <path id="path1127" style={{
                                "fontStyle": "normal",
                                "fontVariant": "normal",
                                "fontWeight": "bold",
                                "fontStretch": "normal",
                                "fontSize": "21.33333397px",
                                "fontFamily": "Calibri",
                                "InkscapeFontSpecification": "'Calibri Bold'",
                                "fill": "#ffffff"
                            }}
                                  d="m 414.83668,50.879416 q 0,1.677083 -0.41667,3 -0.41666,1.322917 -1.23958,2.25 -0.82292,0.916667 -2.04167,1.40625 -1.20833,0.479167 -2.80208,0.479167 -1.57292,0 -2.75,-0.40625 -1.16667,-0.416667 -1.94792,-1.260417 -0.78125,-0.84375 -1.17708,-2.145833 -0.38542,-1.302084 -0.38542,-3.083334 0,-1.635416 0.41667,-2.9375 0.41667,-1.3125 1.23958,-2.229167 0.82292,-0.916666 2.03125,-1.40625 1.21875,-0.489583 2.82292,-0.489583 1.53125,0 2.69792,0.40625 1.17708,0.40625 1.95833,1.25 0.79167,0.84375 1.1875,2.135417 0.40625,1.28125 0.40625,3.03125 z m -2.875,0.145833 q 0,-1.0625 -0.16667,-1.927083 -0.16666,-0.875 -0.57291,-1.489583 -0.39584,-0.625001 -1.0625,-0.958334 -0.66667,-0.34375 -1.66667,-0.34375 -1.01042,0 -1.6875,0.385417 -0.67708,0.375 -1.09375,1.010417 -0.41667,0.635416 -0.59375,1.489583 -0.16667,0.84375 -0.16667,1.791667 0,1.104166 0.16667,1.989583 0.16667,0.875 0.5625,1.5 0.39583,0.625 1.0625,0.958333 0.66667,0.322917 1.67708,0.322917 1.01042,0 1.6875,-0.375 0.67709,-0.375 1.09375,-1.020833 0.41667,-0.645834 0.58334,-1.5 0.17708,-0.864584 0.17708,-1.833334 z"/>
                            <path id="path1129" style={{
                                "fontStyle": "normal",
                                "fontVariant": "normal",
                                "fontWeight": "bold",
                                "fontStretch": "normal",
                                "fontSize": "21.33333397px",
                                "fontFamily": "Calibri",
                                "InkscapeFontSpecification": "'Calibri Bold'",
                                "fill": "#ffffff"
                            }}
                                  d="m 424.5346,56.629416 q 0,0.3125 -0.0312,0.53125 -0.0208,0.208333 -0.0729,0.354167 -0.0521,0.135416 -0.13542,0.197916 -0.0729,0.0625 -0.17708,0.0625 h -6.17708 q -0.34375,0 -0.58334,-0.197916 -0.22916,-0.208334 -0.22916,-0.666667 V 44.671082 q 0,-0.104166 0.0625,-0.1875 0.0729,-0.08333 0.22916,-0.135416 0.15625,-0.05208 0.41667,-0.08333 0.27083,-0.03125 0.66667,-0.03125 0.40625,0 0.66666,0.03125 0.26042,0.03125 0.41667,0.08333 0.15625,0.05208 0.21875,0.135416 0.0729,0.08333 0.0729,0.1875 v 10.843751 h 4.23958 q 0.10417,0 0.17708,0.0625 0.0833,0.05208 0.13542,0.1875 0.0521,0.125 0.0729,0.34375 0.0312,0.208333 0.0312,0.520833 z"/>
                            <path id="path1131" style={{
                                "fontStyle": "normal",
                                "fontVariant": "normal",
                                "fontWeight": "bold",
                                "fontStretch": "normal",
                                "fontSize": "21.33333397px",
                                "fontFamily": "Calibri",
                                "InkscapeFontSpecification": "'Calibri Bold'",
                                "fill": "#ffffff"
                            }}
                                  d="m 433.57626,56.629416 q 0,0.3125 -0.0312,0.53125 -0.0208,0.208333 -0.0729,0.354167 -0.0521,0.135416 -0.13542,0.197916 -0.0729,0.0625 -0.17708,0.0625 h -6.17709 q -0.34375,0 -0.58333,-0.197916 -0.22917,-0.208334 -0.22917,-0.666667 V 44.671082 q 0,-0.104166 0.0625,-0.1875 0.0729,-0.08333 0.22917,-0.135416 0.15625,-0.05208 0.41667,-0.08333 0.27083,-0.03125 0.66666,-0.03125 0.40625,0 0.66667,0.03125 0.26042,0.03125 0.41667,0.08333 0.15625,0.05208 0.21875,0.135416 0.0729,0.08333 0.0729,0.1875 v 10.843751 h 4.23959 q 0.10416,0 0.17708,0.0625 0.0833,0.05208 0.13542,0.1875 0.0521,0.125 0.0729,0.34375 0.0312,0.208333 0.0312,0.520833 z"/>
                        </g>
                        <g id="text1198" style={{
                            "fontStyle": "normal",
                            "fontVariant": "normal",
                            "fontWeight": "bold",
                            "fontStretch": "normal",
                            "fontSize": "42.66666794px",
                            "lineHeight": "1.25",
                            "fontFamily": "Calibri",
                            "InkscapeFontSpecification": "'Calibri Bold'",
                            "letterSpacing": "0px",
                            "wordSpacing": "0px",
                            "fill": "#000000",
                            "fillOpacity": "1",
                            "stroke": "none"
                        }} transform="translate(-342.20449,12.418859)">
                            <path id="path1200" style={{"fill": "#ffffff"}}
                                  d="m 454.25772,50.833333 q 0,1.166666 -0.4375,2.166666 -0.41667,1 -1.20833,1.75 -0.77084,0.75 -1.85417,1.1875 -1.0625,0.416667 -2.35417,0.416667 -1.29166,0 -2.33333,-0.395833 -1.04167,-0.395834 -1.79167,-1.083334 -0.75,-0.708333 -1.14583,-1.6875 -0.39583,-0.979166 -0.39583,-2.145833 0,-1.166667 0.4375,-2.166667 0.4375,-1 1.20833,-1.729166 0.77083,-0.75 1.83333,-1.187501 1.08334,-0.4375 2.35417,-0.4375 1.29167,0 2.33333,0.395834 1.0625,0.395833 1.79167,1.104167 0.75,0.6875 1.14583,1.666666 0.41667,0.979167 0.41667,2.145834 z m -3.58333,0.125 q 0,-0.5 -0.16667,-0.9375 -0.16667,-0.458334 -0.45833,-0.770834 -0.29167,-0.3125 -0.70834,-0.479166 -0.41666,-0.166667 -0.89583,-0.166667 -0.4375,0 -0.85417,0.1875 -0.39583,0.166667 -0.6875,0.479167 -0.27083,0.3125 -0.4375,0.75 -0.16666,0.416666 -0.16666,0.895833 0,0.5 0.16666,0.958333 0.16667,0.4375 0.45834,0.75 0.29166,0.3125 0.70833,0.5 0.41667,0.166667 0.89583,0.166667 0.4375,0 0.83334,-0.166667 0.41666,-0.1875 0.70833,-0.5 0.29167,-0.333333 0.4375,-0.75 0.16667,-0.4375 0.16667,-0.916666 z m -9.47917,-3.604167 z"/>
                        </g>
                        <g id="text1198-5" style={{
                            "fontStyle": "normal",
                            "fontVariant": "normal",
                            "fontWeight": "bold",
                            "fontStretch": "normal",
                            "fontSize": "42.66666794px",
                            "lineHeight": "1.25",
                            "fontFamily": "Calibri",
                            "InkscapeFontSpecification": "'Calibri Bold'",
                            "letterSpacing": "0px",
                            "wordSpacing": "0px",
                            "fill": "#000000",
                            "fillOpacity": "1",
                            "stroke": "none"
                        }} transform="translate(-5.74999,12.469953)">
                            <path id="path1200-0" style={{"fill": "#ffffff"}}
                                  d="m 454.25772,50.833333 q 0,1.166666 -0.4375,2.166666 -0.41667,1 -1.20833,1.75 -0.77084,0.75 -1.85417,1.1875 -1.0625,0.416667 -2.35417,0.416667 -1.29166,0 -2.33333,-0.395833 -1.04167,-0.395834 -1.79167,-1.083334 -0.75,-0.708333 -1.14583,-1.6875 -0.39583,-0.979166 -0.39583,-2.145833 0,-1.166667 0.4375,-2.166667 0.4375,-1 1.20833,-1.729166 0.77083,-0.75 1.83333,-1.187501 1.08334,-0.4375 2.35417,-0.4375 1.29167,0 2.33333,0.395834 1.0625,0.395833 1.79167,1.104167 0.75,0.6875 1.14583,1.666666 0.41667,0.979167 0.41667,2.145834 z m -3.58333,0.125 q 0,-0.5 -0.16667,-0.9375 -0.16667,-0.458334 -0.45833,-0.770834 -0.29167,-0.3125 -0.70834,-0.479166 -0.41666,-0.166667 -0.89583,-0.166667 -0.4375,0 -0.85417,0.1875 -0.39583,0.166667 -0.6875,0.479167 -0.27083,0.3125 -0.4375,0.75 -0.16666,0.416666 -0.16666,0.895833 0,0.5 0.16666,0.958333 0.16667,0.4375 0.45834,0.75 0.29166,0.3125 0.70833,0.5 0.41667,0.166667 0.89583,0.166667 0.4375,0 0.83334,-0.166667 0.41666,-0.1875 0.70833,-0.5 0.29167,-0.333333 0.4375,-0.75 0.16667,-0.4375 0.16667,-0.916666 z m -9.47917,-3.604167 z"/>
                        </g>
                        <path id="rect3422" style={{
                            "fill": "#666666",
                            "fillOpacity": "1",
                            "stroke": "none",
                            "strokeWidth": "2.28176737",
                            "strokeMiterlimit": "4",
                            "strokeDasharray": "none",
                            "strokeOpacity": "1"
                        }}
                              d="M 0 0 L 0 500 L 500 500 L 500 0 L 0 0 z M 250.04883 53.525391 A 197.5 197.5 0 0 1 447.54883 251.02539 A 197.5 197.5 0 0 1 250.04883 448.52539 A 197.5 197.5 0 0 1 52.548828 251.02539 A 197.5 197.5 0 0 1 250.04883 53.525391 z "/>
                        <path id="rect3422-0" style={{
                            "fill": "#666666",
                            "fillOpacity": "1",
                            "stroke": "#000000",
                            "strokeWidth": "2.04426169",
                            "strokeMiterlimit": "4",
                            "strokeDasharray": "none",
                            "strokeOpacity": "1"
                        }}
                              d="M 24.533203 25.509766 L 24.533203 473.4668 L 472.49023 473.4668 L 472.49023 25.509766 L 24.533203 25.509766 z M 250.0625 52.527344 A 197.5 197.5 0 0 1 447.5625 250.02734 A 197.5 197.5 0 0 1 250.0625 447.52734 A 197.5 197.5 0 0 1 52.5625 250.02734 A 197.5 197.5 0 0 1 250.0625 52.527344 z "/>
                        <path id="path3634" style={{
                            "fill": "none",
                            "stroke": "#000000",
                            "strokeWidth": "2.0999999",
                            "strokeLinecap": "butt",
                            "strokeLinejoin": "miter",
                            "strokeMiterlimit": "4",
                            "strokeDasharray": "none",
                            "strokeOpacity": "1"
                        }} d="m 24.630043,25.604561 c 4.809001,4.905942 9.618015,9.811897 14.427044,14.717867"/>
                        <path id="path3638" style={{
                            "fill": "none",
                            "stroke": "#000000",
                            "strokeWidth": "2.0999999",
                            "strokeLinecap": "butt",
                            "strokeLinejoin": "miter",
                            "strokeMiterlimit": "4",
                            "strokeDasharray": "none",
                            "strokeOpacity": "1"
                        }} d="m 24.53413,473.46588 c 5.18607,-4.99556 10.371122,-9.99014 15.555156,-14.98374"/>
                        <path id="path3642" style={{
                            "fill": "none",
                            "stroke": "#000000",
                            "strokeWidth": "2.0999999",
                            "strokeLinecap": "butt",
                            "strokeLinejoin": "miter",
                            "strokeMiterlimit": "4",
                            "strokeDasharray": "none",
                            "strokeOpacity": "1"
                        }} d="m 458.22704,458.20153 c 4.75425,5.08809 9.50852,10.17619 14.26283,15.26435"/>
                        <path id="path3646" style={{
                            "fill": "none",
                            "stroke": "#000000",
                            "strokeWidth": "2",
                            "strokeLinecap": "butt",
                            "strokeLinejoin": "miter",
                            "strokeMiterlimit": "4",
                            "strokeDasharray": "none",
                            "strokeOpacity": "1"
                        }} d="m 471.73772,25.925216 c -4.85565,5.260249 -9.71226,10.521537 -14.56984,15.78387"/>
                        <path id="rect3422-0-5" style={{
                            "fill": "#000000",
                            "fillOpacity": "1",
                            "stroke": "none",
                            "strokeWidth": "1.9306916",
                            "strokeMiterlimit": "4",
                            "strokeDasharray": "none",
                            "strokeOpacity": "1"
                        }}
                              d="M 37.277344 38.453125 L 37.277344 461.52148 L 460.34766 461.52148 L 460.34766 38.453125 L 37.277344 38.453125 z M 250.0625 52.527344 A 197.5 197.5 0 0 1 447.5625 250.02734 A 197.5 197.5 0 0 1 250.0625 447.52734 A 197.5 197.5 0 0 1 52.5625 250.02734 A 197.5 197.5 0 0 1 250.0625 52.527344 z "/>
                        <text id="pitch-value-text" style={{
                            "fontStyle": "normal",
                            "fontWeight": "normal",
                            "fontSize": "32px",
                            "lineHeight": "1.25",
                            "fontFamily": "sans-serif",
                            "letterSpacing": "0px",
                            "wordSpacing": "0px",
                            "fill": "#000000",
                            "fillOpacity": "1",
                            "stroke": "none"
                        }} x="50.472374" y="81.899513" xmlSpace="preserve">
                            <tspan id="tspan1053-9" style={{
                                "fontStyle": "normal",
                                "fontVariant": "normal",
                                "fontWeight": "bold",
                                "fontStretch": "normal",
                                "fontSize": "32px",
                                "fontFamily": "Calibri",
                                "InkscapeFontSpecification": "'Calibri Bold'",
                                "fill": "#ffffff"
                            }} x="50.472374" y="81.899513">{pitch} &#176;
                            </tspan>
                        </text>
                        <text id="roll-value-text" style={{
                            "fontStyle": "normal",
                            "fontWeight": "normal",
                            "fontSize": "32px",
                            "lineHeight": "1.25",
                            "fontFamily": "sans-serif",
                            "letterSpacing": "0px",
                            "wordSpacing": "0px",
                            "fill": "#000000",
                            "fillOpacity": "1",
                            "stroke": "none"
                        }} x="386.92688" y="81.950623" xmlSpace="preserve">
                            <tspan id="tspan1053-9-3" style={{
                                "fontStyle": "normal",
                                "fontVariant": "normal",
                                "fontWeight": "bold",
                                "fontStretch": "normal",
                                "fontSize": "32px",
                                "fontFamily": "Calibri",
                                "InkscapeFontSpecification": "'Calibri Bold'",
                                "fill": "#ffffff"
                            }} x="386.92688" y="81.950623">{roll} &#176;
                            </tspan>
                        </text>
                    </g>
                </svg>
            </div>
        </div>
    );
}

export default App;
